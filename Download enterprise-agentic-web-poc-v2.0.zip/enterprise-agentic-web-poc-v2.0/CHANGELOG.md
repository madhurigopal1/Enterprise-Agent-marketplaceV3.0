# Changelog

## 2.0.0
Twenty new features (21-40), see docs/FEATURES.md.
- New modules: settings, guardrails, resilience, workflows, persistence.
- Governance: segregation of duties, approval SLA + escalation, hash-chained audit with verification, certification checklist, governed updates with re-certification, retention purge.
- Safety: PII redaction, prompt-injection guard (block / flag / off), per-user rate limiting.
- Reliability: retries with backoff, per-agent circuit breaker (new "Agent health" policy check), fault injection, JSON persistence.
- Productivity: dry run, cancel, re-run, workflow templates, notifications, marketplace filters and sort.
- Operations: Admin tab, budget administration and alerts, chargeback report, Prometheus /metrics.
- Tests: 30 -> 51. Browser click-through of every new flow.

## 1.1.0-features
- docs/FEATURES.md: top 20 features with user stories, acceptance criteria and test mapping.
- Approval comments and rejection reasons (stored on step, in report and audit); `POC_REQUIRE_REJECT_REASON` option.
- Bulk approve/reject with per-item permission checks and partial-success results (`POST /api/approvals/bulk`).
- My Runs tab with status filter and reopen.
- Agent ratings 1-5 per completed step, with average and count in agent details.
- Agent kill switch for Platform Admin; new "Kill switch" policy check; suspend/resume audited.
- Markdown run report download; audit CSV export for Compliance Officer and Platform Admin.
- Fix: a step that completed after approval no longer shows the stale "Human approval required" note.
- Tests: 22 → 30; browser click-through extended.

## 1.0.0-approvals
**Fixes "Approvals tab not visible"**
- Approvals tab with live count badge, approval cards (requester, intent, input, resources, cost) and Approve & continue / Reject with confirmation.
- Inline approve/reject on the paused step in the Ask tab.
- `GET /api/approvals` inbox endpoint (replaces N+1 client calls).
- Compliance Officers may now decide approvals (previously requester or Platform Admin only).
- Cache busting: `Cache-Control: no-store`, `?v=<version>` asset URLs, version shown in header/footer/title.
- `/api/version` and an `approvals_ui` check in `/api/ready`; `scripts/check_ui.ps1` diagnostic.
- `run.py` refuses to start if the port is already in use (prevents an old instance shadowing the new one).

**Restored and improved UX**
- Restored the Register Agent tab and Policy simulator (both described in the README but missing from 0.2).
- Marketplace agent details with policy checks, Try it, and one-step lifecycle promotion for Platform Admin.
- Execution plan with per-step policy decision and scoped delegation; findings and consolidated recommendations.
- Audit filter by action; observability per-agent table.
- All dynamic content HTML-escaped (prevents script injection via registered agent names).
- Keyboard focus styles, ARIA tabs/live regions, skip link, responsive layout, remembered user and tab.

**Quality**
- Correlation ID, process-time, version, nosniff and no-referrer headers; local-only CORS.
- Unknown / more than 6 manual agent IDs rejected with 422; audit limit bounded 1–1000.
- Pydantic default factories; thread-safe spend accounting; `POC_SECRET`/`POC_HOST`/`POC_PORT` env vars.
- Tests: 13 → 22, plus optional browser click-through.
