# Enterprise Agentic Web - 40 Features and User Stories (v2.0.0)

Personas: **Priya** (Business Analyst), **Arjun** (Finance Manager), **Meera** (Compliance Officer), **Kiran** (Agent Owner), **Sam** (Platform Admin).
Status: **Built** = in the POC before v1.1 · **v1.1** = added in v1.1 · **New v2.0** = features 21-40 added in this release. Every feature has an automated test.

| # | Feature | Status | Where |
|---|---|---|---|
| 1 | Intent-based agent discovery | Built | Marketplace, Ask → Preview · `POST /api/discover` |
| 2 | Multi-agent composition and one consolidated result | Built | Ask · `POST /api/runs` |
| 3 | Human approval inbox (HITL) | Built (v1.0) | Approvals tab · `GET /api/approvals` |
| 4 | Zero-trust policy decision per step | Built | Ask → Policy decision |
| 5 | Scoped delegation (no permission inheritance) | Built | Ask → Policy decision |
| 6 | Agent registration with validation | Built | Register Agent · `POST /api/agents` |
| 7 | Lifecycle certification gate | Built | Marketplace → Details → Promote |
| 8 | Policy simulator | Built | Governance & Audit |
| 9 | Immutable-style audit trail | Built | Governance & Audit · `GET /api/audit` |
| 10 | Pilot KPI observability | Built | Observability · `GET /api/metrics` |
| 11 | Budget and quota guard | Built | Header budget, policy check |
| 12 | Provider abstraction layer (5 providers) | Built | `app/adapters.py` |
| 13 | Explainable access preview | Built | Marketplace cards and details |
| 14 | Approval comments and rejection reasons | v1.1 | Approve/Reject prompts · `decision.comment` |
| 15 | Bulk approvals | v1.1 | Approvals → Select all · `POST /api/approvals/bulk` |
| 16 | Run history | v1.1 | My Runs tab · `GET /api/runs` |
| 17 | Agent ratings and feedback | v1.1 | Ask → Rate ★ · `POST /api/runs/{id}/feedback` |
| 18 | Agent kill switch | v1.1 | Marketplace → Details (Admin) · `POST /api/agents/{id}/suspend` |
| 19 | Run report download | v1.1 | Ask → Download report · `GET /api/runs/{id}/report` |
| 20 | Audit log CSV export | v1.1 | Governance → Export CSV · `GET /api/audit/export` |
| 21 | Segregation of duties for approvals | **New v2.0** | Admin → Settings · `segregation_of_duties` |
| 22 | Approval SLA with automatic escalation | **New v2.0** | Approvals (due / overdue) · `approval_sla_minutes` |
| 23 | In-app notifications | **New v2.0** | Bell in header · `GET /api/notifications` |
| 24 | Durable state (snapshot persistence) | **New v2.0** | `POC_PERSIST=true` · Admin → Save snapshot |
| 25 | Dry run: plan, policy and cost preview | **New v2.0** | Ask → Dry run · `POST /api/runs/plan` |
| 26 | Cancel a run | **New v2.0** | Ask / My Runs → Cancel · `POST /api/runs/{id}/cancel` |
| 27 | Re-run a previous run | **New v2.0** | Ask / My Runs → Re-run · `POST /api/runs/{id}/rerun` |
| 28 | Workflow templates | **New v2.0** | Ask → template selector, Save as template · `/api/templates` |
| 29 | PII redaction before agents | **New v2.0** | Step note "PII masked" · `app/guardrails.py` |
| 30 | Prompt-injection guard | **New v2.0** | Live warning on Ask; 422 when blocked |
| 31 | Tamper-evident audit (hash chain) | **New v2.0** | Governance → Verify integrity · `GET /api/audit/verify` |
| 32 | Per-user run rate limiting | **New v2.0** | HTTP 429 + Retry-After |
| 33 | Retries and circuit breaker per agent | **New v2.0** | Admin → Agent health; "Agent health" policy check |
| 34 | Budget administration and alerts | **New v2.0** | Admin → User budgets; 80% notification |
| 35 | Marketplace filters and sorting | **New v2.0** | Marketplace filter bar · `GET /api/agents?…`, `/api/agents/facets` |
| 36 | Chargeback report | **New v2.0** | Observability → Chargeback · `GET /api/reports/chargeback` |
| 37 | Automated certification checklist | **New v2.0** | Marketplace → Details · `GET /api/agents/{id}/certification` |
| 38 | Governed agent updates with re-certification | **New v2.0** | Marketplace → Details → Edit · `PATCH /api/agents/{id}` |
| 39 | Prometheus metrics endpoint | **New v2.0** | `GET /metrics` |
| 40 | Data retention purge | **New v2.0** | Admin → Data retention · `POST /api/admin/purge` |

---

## 1. Intent-based agent discovery
**As** Priya, **I want** to describe a business need in plain language **so that** I find the right agent without knowing agent names.
- Results are ranked by relevance with matched terms.
- "Check customer onboarding documents" ranks the KYC agent first.
- Each result shows whether I can use it.
Test: `test_discovery_by_intent`

## 2. Multi-agent composition and one consolidated result
**As** Priya, **I want** the platform to select and sequence several agents for my intent **so that** I get one readiness verdict instead of six separate outputs.
- Up to 6 agents, ordered by stage.
- Vague spec → "Not ready"; well-specified spec → "Ready for development".
- Totals for agents run, cost, tokens and latency are shown.
Test: `test_multi_agent_run_bad_vs_good_spec`

## 3. Human approval inbox
**As** Meera, **I want** every agent run that needs sign-off to wait in one inbox **so that** consequential actions never run without a human.
- Finance and KYC agents pause with status `awaiting_approval`.
- The Approvals tab shows a count badge and a card per paused step.
- Only the requester, a Compliance Officer or a Platform Admin can decide. Others get 403.
Tests: `test_human_approval_flow`, `test_kyc_run_appears_in_meera_inbox_and_she_can_approve`, `test_business_analyst_sees_no_one_elses_approvals_and_cannot_decide`

## 4. Zero-trust policy decision per step
**As** Meera, **I want** each agent call evaluated against identity, role, region, classification, lifecycle, kill switch, resources and budget **so that** I can see exactly why it was allowed or denied.
- Every step stores its list of checks.
- The first failing check becomes the visible reason.
Test: `test_rbac_blocks_and_audits`

## 5. Scoped delegation
**As** Sam, **I want** agents to receive only their declared resource scopes **so that** an agent never inherits the user's or upstream agents' permissions.
- `inherits_user_permissions` and `inherits_upstream_agent_permissions` are always false.
Test: `test_delegation_is_scoped`

## 6. Agent registration
**As** Kiran, **I want** to register an agent through a validated form **so that** it enters the catalog with ownership and policy metadata.
- Only Agent Owners and Platform Admins can register.
- Duplicate or invalid IDs are rejected with field-level errors.
Test: `test_registration_and_lifecycle_gate`

## 7. Lifecycle certification gate
**As** Sam, **I want** to promote agents one step at a time through Validated → Certified → Production **so that** uncertified agents cannot be invoked.
- Skipping a stage returns 409.
- A Registered agent is blocked until it reaches Certified.
Test: `test_registration_and_lifecycle_gate`

## 8. Policy simulator
**As** Meera, **I want** to test whether any user can invoke any agent **so that** I can validate access rules before an audit.
- Shows every check, including role and region failures.
Test: `test_policy_simulation_region_abac`

## 9. Audit trail
**As** Meera, **I want** every invocation, approval request, decision, registration, promotion and suspension logged **so that** I can reconstruct who did what.
- Compliance Officers and Admins see all events; other users see only their own.
- The log can be filtered by action.
Tests: `test_rbac_blocks_and_audits`, `test_rejected_step_never_executes_and_is_audited`

## 10. Pilot KPI observability
**As** Sam, **I want** pilot KPIs against targets (agents onboarded, providers, discovery >90%, execution >95%) **so that** I can report pilot success.
- Cost, tokens and latency are shown per agent.
Test: `test_metrics_kpis`

## 11. Budget and quota guard
**As** Sam, **I want** each user to have a spend budget **so that** agent costs cannot run away.
- A call is blocked when remaining budget is below the call cost.
- Remaining budget is shown in the header.
Test: `test_budget_quota`

## 12. Provider abstraction layer
**As** Kiran, **I want** one normalized contract across Neuro SAN, NANDA-inspired, Otari, AWS Bedrock and Enterprise API **so that** consumers don't depend on a provider.
- Swapping a provider only touches `app/adapters.py`.
Test: covered by all run tests

## 13. Explainable access preview
**As** Priya, **I want** to see before running whether I can use an agent, and why not **so that** I don't hit unexplained failures.
- Marketplace cards show "You can use this agent" or the failing policy reason.
Test: `test_catalog_size_and_access_preview`

## 14. Approval comments and rejection reasons (v1.1)
**As** Meera, **I want** to add a comment when I approve and a reason when I reject **so that** the audit shows why a decision was made.
- The UI always asks for a reason (at least 3 characters) to reject.
- The comment is stored on the step, shown in the run and written to the audit `reason`.
- Set `POC_REQUIRE_REJECT_REASON=true` to enforce the reason for API clients too.
Test: `test_reject_requires_reason_and_comment_is_recorded`

## 15. Bulk approvals (v1.1)
**As** Meera, **I want** to approve or reject several pending steps at once **so that** I can clear a backlog quickly.
- Select all or individual cards; buttons show the selected count.
- Each item is permission-checked; per-item success or failure is returned (partial success allowed).
Tests: `test_bulk_approve_partial_success`, `test_bulk_respects_permissions`

## 16. Run history (v1.1)
**As** Arjun, **I want** a list of my past runs with status **so that** I can reopen results and finish pending approvals.
- Filter by status; Open reloads the full run in the Ask tab.
- Compliance Officers and Admins see all runs.
Test: UI marker test `test_ui_has_v11_controls` and browser click-through

## 17. Agent ratings and feedback (v1.1)
**As** Priya, **I want** to rate an agent 1–5 after it completes **so that** agent owners get quality signals.
- Only the run owner can rate, only completed steps, and a re-rating replaces the earlier one.
- Agent details show the average and count.
Test: `test_feedback_only_for_completed_steps_and_aggregates`

## 18. Agent kill switch (v1.1)
**As** Sam, **I want** to suspend a misbehaving agent immediately, with a reason **so that** no new invocations run during an incident.
- Suspension adds a failing "Kill switch" policy check showing the reason.
- Resume restores access. Both actions are audited. Only Platform Admin can use it.
Test: `test_kill_switch_blocks_and_resumes`

## 19. Run report download (v1.1)
**As** Arjun, **I want** to download a run as a Markdown report **so that** I can attach it to a decision record.
- Includes intent, status, headline, each step, human decision with comment, scopes and recommendations.
- Only users who can view the run can download it.
Test: `test_run_report_markdown`

## 20. Audit log CSV export (v1.1)
**As** Meera, **I want** to export the audit log as CSV **so that** I can hand evidence to auditors.
- Only Compliance Officer and Platform Admin; the export itself is audited.
Test: `test_audit_csv_export_rbac`

---

## 21. Segregation of duties (New v2.0)
**As** Meera (Compliance Officer), **I want** requesters to be unable to approve their own Finance or KYC runs **so that** every consequential action has a second person's sign-off.
- When on, the requester gets 403 with a clear reason and the item is removed from their Approvals inbox.
- Compliance Officers and Platform Admins can still decide; the requester's Ask screen explains who must decide.
- Off by default so the original demo scripts keep working; Platform Admin switches it on in Admin → Settings (or `POC_SOD=true`).
Test: `test_21_segregation_of_duties`

## 22. Approval SLA with automatic escalation (New v2.0)
**As** Meera, **I want** overdue approvals escalated automatically **so that** paused business processes don't stall silently.
- Each paused step gets a due time (default 60 minutes, configurable).
- When overdue it is marked escalated once, audited as `escalate`, and every Compliance Officer and Platform Admin is notified.
- Cards show "Due" or "Overdue · escalated".
Test: `test_22_sla_escalation_notifies_approvers_once`

## 23. In-app notifications (New v2.0)
**As** Arjun, **I want** to be told when my request is approved or rejected **so that** I don't have to keep checking.
- Approvers are notified of new approvals and escalations; requesters of decisions; users of budget changes and alerts.
- The bell shows the unread count; "Mark all read" clears it; items link to the right tab.
Test: `test_23_notifications_request_and_decision`

## 24. Durable state (New v2.0)
**As** Sam, **I want** runs, audit, agents, templates and settings to survive a restart **so that** pilot evidence isn't lost.
- `POC_PERSIST=true` loads `data/state.json` at start-up and saves after every successful change and at shutdown.
- Writes are atomic (temp file + rename). Admin can save a snapshot on demand.
- Verified: a run created before restart is readable after restart and the audit chain still verifies.
Test: `test_24_persistence_round_trip`

## 25. Dry run (New v2.0)
**As** Priya, **I want** to see which agents would run, which would be blocked and what it would cost **before** I run anything **so that** I can fix access or input first.
- Shows would-run / reason, approvals needed, PII masking and estimated cost vs remaining budget.
- Nothing executes, nothing is charged and no run is created.
Test: `test_25_dry_run_executes_nothing`

## 26. Cancel a run (New v2.0)
**As** Arjun, **I want** to cancel a run that is waiting for approval **so that** a mistaken or duplicate request never executes.
- Requester or Platform Admin only; remaining steps become `cancelled`; a later decision returns 409; audited.
Test: `test_26_cancel_and_27_rerun`

## 27. Re-run (New v2.0)
**As** Priya, **I want** to re-run a previous workflow with one click **so that** I can repeat a check after changing something.
- Same intent, input and agents; new run records `rerun_of`; owner only; rate-limited like any run.
Test: `test_26_cancel_and_27_rerun`

## 28. Workflow templates (New v2.0)
**As** Priya, **I want** to save and reuse a reviewed list of agents **so that** recurring checks are consistent.
- Two shared seed templates (readiness check, month-end finance review).
- Save the agents of your last run as a private or shared template; usage is counted.
- Only the owner or a Platform Admin can delete; templates with missing agents return 409.
Test: `test_28_templates`

## 29. PII redaction (New v2.0)
**As** Meera, **I want** personal data masked before it reaches agents that aren't cleared for it **so that** we meet data-minimisation obligations.
- Email, card, phone, Aadhaar, PAN, SSN and IBAN patterns are masked for Public/Internal agents.
- Confidential/Restricted agents (e.g. KYC) receive the original data. Counts are shown per step and audited.
Test: `test_29_pii_redaction_for_internal_agents_only`

## 30. Prompt-injection guard (New v2.0)
**As** Sam, **I want** inputs that try to override instructions or exfiltrate secrets blocked **so that** agents can't be manipulated.
- Modes: `block` (default, HTTP 422 + audit), `flag` (runs, but flags are shown and audited), `off`.
- The Ask tab warns while you type.
Test: `test_30_prompt_injection_block_and_flag`

## 31. Tamper-evident audit (New v2.0)
**As** Meera, **I want** to prove the audit log hasn't been altered **so that** it stands up as evidence.
- Each event stores the previous event's SHA-256 hash; verification recomputes the chain and reports the first broken event.
- Compliance Officer and Platform Admin only.
Test: `test_31_audit_hash_chain_detects_tampering`

## 32. Rate limiting (New v2.0)
**As** Sam, **I want** to cap how many runs one user can start per minute **so that** a script or mistake can't flood providers.
- Sliding one-minute window (default 60), HTTP 429 with `Retry-After`, audited as `rate_limit`.
Test: `test_32_rate_limit`

## 33. Retries and circuit breaker (New v2.0)
**As** Sam, **I want** transient provider errors retried and persistently failing agents isolated **so that** one bad provider doesn't degrade every workflow.
- Exponential-backoff retries (default 2); attempts are shown per step.
- After N consecutive failed calls the circuit opens and the "Agent health" policy check blocks the agent; it half-opens after the cool-down.
- Admin can inject faults (0-100%) and reset a circuit.
Test: `test_33_retry_and_circuit_breaker`

## 34. Budget administration and alerts (New v2.0)
**As** Sam, **I want** to adjust user budgets and warn users before they run out **so that** costs stay predictable.
- Admin → User budgets shows spent, budget and % used; changes are audited and the user is notified.
- Users get one alert when spend crosses 80% (configurable).
Test: `test_34_budget_admin_and_alert`

## 35. Marketplace filters and sorting (New v2.0)
**As** Priya, **I want** to filter agents by provider, status, classification, approval and "usable by me" and sort them **so that** I find a suitable agent quickly.
- Facet counts populate the filter lists; sort by name, rating, quality or cost.
Test: `test_35_marketplace_facets_and_sort`

## 36. Chargeback (New v2.0)
**As** Sam, **I want** completed-call cost grouped by user, provider or agent **so that** I can allocate spend.
- Compliance Officers and Admins see everyone; other users see only their own usage.
Test: `test_36_chargeback_scoping`

## 37. Automated certification checklist (New v2.0)
**As** Sam, **I want** promotion to Validated, Certified or Production blocked when security basics are missing **so that** risky agents can't be certified by mistake.
- Blocking: owner, version, explicit roles for Confidential/Restricted, approval for Restricted, cost cap, declared resources.
- Advisory (shown, not blocking): description length, capabilities, keywords.
Test: `test_37_certification_checklist_blocks_promotion`

## 38. Governed agent updates (New v2.0)
**As** Kiran, **I want** to update my agent's metadata **so that** the catalog stays accurate, **and as** Sam **I want** security-relevant changes to force re-certification.
- Agent Owner or Platform Admin; change history and audit record the changed fields.
- Changing roles, regions, resources, classification or approval on a Certified/Production agent moves it back to Validated.
Test: `test_38_material_update_forces_recertification`

## 39. Prometheus metrics (New v2.0)
**As** an SRE, **I want** platform metrics in Prometheus format **so that** I can dashboard and alert on them.
- `/metrics`: invocations by decision/outcome, runs by status, cost, pending approvals, agents by status, open circuits, audit events.
Test: `test_39_prometheus_metrics`

## 40. Data retention purge (New v2.0)
**As** Meera, **I want** old run data deleted on a schedule we choose **so that** we don't keep inputs longer than policy allows.
- Preview (dry run) first; open runs and audit events are never deleted; the purge itself is audited.
Test: `test_40_retention_purge`

---

## Candidate next features (not built)
Entra ID SSO, real provider SDKs, embeddings-based discovery, Teams/email delivery of notifications, agent version pinning and canary release, OPA/Cedar policy engine, PostgreSQL storage, multi-tenant isolation.
