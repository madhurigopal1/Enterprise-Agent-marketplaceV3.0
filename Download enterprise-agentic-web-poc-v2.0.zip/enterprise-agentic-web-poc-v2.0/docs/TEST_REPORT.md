# Test report - v2.0.0

`python -m pytest -q` -> **51 passed** (13 original + 9 approval/UI + 8 v1.1 + 21 v2.0). Passes in both file orders.

## Browser click-through (headless Chromium, tests/e2e_browser.py)
- 8 tabs: Ask, Marketplace, Register Agent, My Runs, Approvals, Governance & Audit, Observability, Admin
- Sam: Admin → enable segregation of duties, SLA 0 → saved
- Arjun: template "Month-end finance review" → Dry run ($0.14, 1 approval) → PII warning for an email → run pauses; no Approve buttons shown (SoD)
- Prompt injection text → live warning → run refused (422)
- Meera: bell = 2 (approval + escalation) → Approvals card "Overdue · escalated" → approve
- Governance → Verify integrity: chain intact
- Observability → Chargeback by provider
- Kiran: Marketplace filter Confidential = 4 agents → certification checklist shown
- Arjun: My Runs → Re-run → Cancel run → cancelled
- Sam: fault injection on Documentation Agent; retention preview
- Only console entry: the intentional 422 from the blocked injection

## Persistence (real restart)
POC_PERSIST=true: created a run, stopped the server, restarted: run readable, audit chain valid.

Providers, SSO, agent logic and costs remain simulated.
