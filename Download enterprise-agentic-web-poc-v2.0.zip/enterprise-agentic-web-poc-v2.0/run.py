"""Start the POC. Env vars: POC_HOST (127.0.0.1), POC_PORT (8000), POC_RELOAD (false)."""
import os
import socket
import sys

import uvicorn

if __name__ == "__main__":
    host = os.getenv("POC_HOST", "127.0.0.1")
    port = int(os.getenv("POC_PORT", "8000"))
    with socket.socket() as s:
        if s.connect_ex((host, port)) == 0:
            sys.exit(f"Port {port} is already in use - an OLD copy of the POC is probably still running.\n"
                     f"Stop it first (see README 'Troubleshooting'), or run with POC_PORT=8010.")
    from app.main import APP_VERSION
    print(f"Enterprise Agentic Web POC v{APP_VERSION} -> http://{host}:{port}   (API docs: /docs)")
    print(f"Serving UI from: {os.path.join(os.path.dirname(os.path.abspath(__file__)), 'app', 'static')}")
    uvicorn.run("app.main:app", host=host, port=port, reload=os.getenv("POC_RELOAD", "false").lower() == "true")
