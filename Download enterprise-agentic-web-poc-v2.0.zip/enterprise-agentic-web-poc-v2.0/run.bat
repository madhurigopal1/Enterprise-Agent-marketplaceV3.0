@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
if not exist .venv (
  echo Creating virtual environment...
  %PY% -m venv .venv || (echo Python 3.10+ is required. & exit /b 1)
)
call .venv\Scripts\activate.bat
python -m pip install -q -r requirements.txt || exit /b 1
python run.py
