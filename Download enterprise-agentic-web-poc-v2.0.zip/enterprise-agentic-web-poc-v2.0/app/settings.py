"""Runtime platform settings (feature 21, 22, 29, 30, 32). Platform Admin edits them in the Admin tab.

Defaults keep the original demo scripts working; env vars override at start-up.
"""
import os

_b = lambda k, d: os.getenv(k, str(d)).lower() == "true"

SETTINGS = {
    # 21 Segregation of duties: requester may NOT approve their own run (off by default so the original demo flow works)
    "segregation_of_duties": _b("POC_SOD", False),
    # 22 Approval SLA in minutes; overdue approvals are escalated to Compliance Officers and Platform Admins
    "approval_sla_minutes": float(os.getenv("POC_APPROVAL_SLA_MIN", "60")),
    # 29 Mask PII before it reaches agents cleared only for Public / Internal data
    "pii_redaction": _b("POC_PII_REDACTION", True),
    # 30 Prompt-injection guard: "block", "flag" or "off"
    "injection_guard": os.getenv("POC_INJECTION_GUARD", "block"),
    # 32 Max runs a user may start per minute
    "run_rate_limit_per_min": int(os.getenv("POC_RUN_RATE_LIMIT", "60")),
    # 34 Notify a user when spend crosses this share of their budget
    "budget_alert_ratio": 0.8,
    # 33 Circuit breaker: consecutive failures to open, seconds to stay open, retries per call
    "breaker_threshold": 3,
    "breaker_cooldown_sec": 30,
    "max_retries": 2,
}

TYPES = {"segregation_of_duties": bool, "approval_sla_minutes": float, "pii_redaction": bool, "injection_guard": str,
         "run_rate_limit_per_min": int, "budget_alert_ratio": float, "breaker_threshold": int, "breaker_cooldown_sec": int,
         "max_retries": int}
LIMITS = {"approval_sla_minutes": (0, 10080), "run_rate_limit_per_min": (1, 10000), "budget_alert_ratio": (0.1, 1.0),
          "breaker_threshold": (1, 20), "breaker_cooldown_sec": (1, 3600), "max_retries": (0, 5)}


def update(changes: dict) -> dict:
    errors = []
    clean = {}
    for k, v in changes.items():
        if k not in TYPES:
            errors.append(f"unknown setting '{k}'"); continue
        t = TYPES[k]
        if t is bool and not isinstance(v, bool):
            errors.append(f"'{k}' must be true/false"); continue
        try:
            v = t(v)
        except (TypeError, ValueError):
            errors.append(f"'{k}' must be {t.__name__}"); continue
        if k == "injection_guard" and v not in ("block", "flag", "off"):
            errors.append("'injection_guard' must be block, flag or off"); continue
        if k in LIMITS and not (LIMITS[k][0] <= v <= LIMITS[k][1]):
            errors.append(f"'{k}' must be between {LIMITS[k][0]} and {LIMITS[k][1]}"); continue
        clean[k] = v
    if errors:
        raise ValueError(errors)
    SETTINGS.update(clean)
    return clean
