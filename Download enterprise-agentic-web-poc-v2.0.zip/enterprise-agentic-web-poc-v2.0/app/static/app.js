'use strict';
/* Enterprise Agentic Web POC - UI (no external dependencies). */
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
const state = { token: '', me: null, users: [], samples: [], agents: [], lastRunId: null };

/* ---------- helpers ---------- */
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = v => `$${Number(v || 0).toFixed(2)}`;
const STATUS_BADGE = {
  completed: 'b-ok', allow: 'b-ok', approve: 'b-ok', Production: 'b-ok', Certified: 'b-ok', ready: 'b-ok',
  awaiting_approval: 'b-warn', pending: 'b-warn', running: 'b-warn', partial: 'b-warn', Validated: 'b-warn', Registered: 'b-warn',
  blocked: 'b-bad', rejected: 'b-bad', failed: 'b-bad', deny: 'b-bad', reject: 'b-bad', Experimental: 'b-bad', Deprecated: 'b-bad'
};
const badge = s => `<span class="badge ${STATUS_BADGE[s] || ''}">${esc(String(s ?? '—').replace(/_/g, ' '))}</span>`;

let toastTimer;
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.style.display = 'block';
  clearTimeout(toastTimer); toastTimer = setTimeout(() => (t.style.display = 'none'), 4000);
}

async function api(path, opt = {}) {
  const headers = { ...(opt.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  if (opt.body) headers['Content-Type'] = 'application/json';
  const r = await fetch(path, { ...opt, headers, cache: 'no-store' });
  const data = await r.json().catch(() => ({ detail: r.statusText }));
  if (!r.ok) {
    const d = data.detail;
    const msg = typeof d === 'string' ? d : d && d.error ? d.error : Array.isArray(d) ? d.map(x => x.msg || x).join('; ') : JSON.stringify(d);
    throw new Error(`${r.status}: ${msg}`);
  }
  return data;
}

async function busy(btn, fn) {
  const label = btn.textContent; btn.disabled = true; btn.textContent = 'Working…';
  try { return await fn(); } catch (e) { toast(e.message); } finally { btn.disabled = false; btn.textContent = label; }
}

/* ---------- tabs ---------- */
function showTab(name) {
  $$('.tabs button').forEach(b => b.setAttribute('aria-selected', String(b.dataset.tab === name)));
  $$('.panel').forEach(p => p.classList.toggle('hidden', p.id !== name));
  if (name === 'approvals') loadApprovals();
  if (name === 'runs') loadRuns();
  if (name === 'admin') loadAdmin();
  if (name === 'governance') loadAudit();
  if (name === 'observability') { loadMetrics(); loadChargeback(); }
  if (name === 'market' && !$('#agents').innerHTML) loadAgents();
  history.replaceState(null, '', `#${name}`);
}
$$('.tabs button').forEach(b => (b.onclick = () => showTab(b.dataset.tab)));

/* ---------- identity ---------- */
async function login() {
  const d = await api('/api/login', { method: 'POST', body: JSON.stringify({ user_id: $('#user').value }) });
  state.token = d.token; state.me = d.user;
  localStorage.setItem('poc-user', d.user.id);
  const me = await api('/api/me');
  state.sod = me.segregation_of_duties;
  $('#meInfo').textContent = `${me.role} · ${me.region} · clearance ${me.clearance} · budget left ${money(me.remaining_usd)}`;
  $('#agents').innerHTML = ''; $('#agentDetail').innerHTML = '';
  await refreshApprovalCount();
  await Promise.all([loadNotifications(), loadTemplates()]);
  const active = $$('.tabs button').find(b => b.getAttribute('aria-selected') === 'true');
  if (active) showTab(active.dataset.tab);
}

/* ---------- ASK ---------- */
$('#sample').onchange = e => {
  if (e.target.value === '') return;
  const s = state.samples[+e.target.value];
  $('#intent').value = s.intent; $('#input').value = s.text;
};

$('#preview').onclick = () => busy($('#preview'), async () => {
  const q = $('#intent').value.trim();
  if (q.length < 2) return toast('Enter an intent first.');
  const d = await api('/api/discover', { method: 'POST', body: JSON.stringify({ query: q }) });
  $('#previewOut').innerHTML = d.results.length
    ? `<div class="tablewrap"><table><thead><tr><th>Agent</th><th>Relevance</th><th>Access for you</th><th>Approval</th></tr></thead><tbody>${d.results.map(r => `
      <tr><td>${esc(r.agent.name)}</td><td>${(r.score * 100).toFixed(0)}%</td>
      <td>${r.agent.access.allowed ? '<span class="ok">Allowed</span>' : `<span class="bad">${esc(r.agent.access.reason)}</span>`}</td>
      <td>${r.agent.requires_approval ? badge('awaiting_approval') : '—'}</td></tr>`).join('')}</tbody></table></div>`
    : '<div class="empty">No matching agents. Try a more specific business intent.</div>';
});

$('#run').onclick = () => busy($('#run'), async () => {
  const intent = $('#intent').value.trim();
  if (intent.length < 2) return toast('Enter an intent (at least 2 characters).');
  $('#runStatus').textContent = 'Running governed workflow…';
  const r = await api('/api/runs', { method: 'POST', body: JSON.stringify({ intent, input_text: $('#input').value }) });
  renderRun(r);
  await refreshApprovalCount();
});

function renderRun(r) {
  state.lastRunId = r.id;
  const waiting = r.steps.filter(s => s.status === 'awaiting_approval');
  $('#runStatus').innerHTML = `Run <code>${esc(r.id)}</code> ${badge(r.status)}` +
    (waiting.length ? ` <span class="warn">Paused for human approval. Decide below or in the <a href="#approvals" onclick="showTab('approvals');return false">Approvals</a> tab.</span>` : '');
  const res = r.result;
  const head = res ? `<p class="headline">${esc(res.headline)}</p>
     <p class="hint">Agents run: ${res.totals.agents_run ?? 0} · cost ${money(res.totals.cost_usd)} · tokens ${res.totals.tokens ?? 0} · simulated latency ${res.totals.simulated_latency_sec ?? 0}s</p>` : '';
  const steps = r.steps.map((s, i) => `
    <div class="step ${esc(s.status)}">
      <div class="n">${i + 1}</div>
      <div>
        <b>${esc(s.agent_name)}</b> <span class="hint">· ${esc(s.provider)} v${esc(s.version)}</span> ${badge(s.status)}
        ${s.note ? `<div class="${s.status === 'awaiting_approval' ? 'warn' : 'bad'}">${esc(s.note)}</div>` : ''}
        ${s.approval_due && s.status === 'awaiting_approval' ? `<div class="hint">Decision due ${esc(s.approval_due)}${s.escalated ? ' · <b class="bad">escalated</b>' : ''}</div>` : ''}
        ${s.redactions && Object.keys(s.redactions).length ? `<div class="hint">PII masked before this agent: ${esc(Object.entries(s.redactions).map(([k, v]) => `${v} ${k}`).join(', '))}</div>` : ''}
        ${s.attempts > 1 ? `<div class="hint">${s.attempts} attempts (retried after provider errors)</div>` : ''}
        ${s.status === 'awaiting_approval' && state.sod && r.user === state.me.id ? `<div class="hint">Segregation of duties is on: a Compliance Officer or Platform Admin must decide.</div>` : ''}
        ${s.status === 'awaiting_approval' && !(state.sod && r.user === state.me.id) ? `<div class="row">
            <button class="approve" type="button" onclick="decide('${esc(r.id)}','${esc(s.agent_id)}',true,this)">Approve &amp; continue</button>
            <button class="danger" type="button" onclick="decide('${esc(r.id)}','${esc(s.agent_id)}',false,this)">Reject</button></div>` : ''}
        ${s.approval ? `<div class="hint">Human decision: <b>${s.approval.approve ? 'approved' : 'rejected'}</b> by ${esc(s.approval.by)} (${esc(s.approval.role)})${s.approval.comment ? ` · “${esc(s.approval.comment)}”` : ''}</div>` : ''}
        ${s.status === 'completed' && r.user === (state.me && state.me.id) ? `<div class="stars" aria-label="Rate ${esc(s.agent_name)}">Rate: ${[1,2,3,4,5].map(n => `<button type="button" aria-label="${n} star" onclick="rate('${esc(r.id)}','${esc(s.agent_id)}',${n},this)">★</button>`).join('')}</div>` : ''}
        ${s.output ? `<div><b>${esc(s.output.verdict || '')}</b> ${esc(s.output.summary || '')}</div>
          ${(s.output.findings || []).length ? `<ul>${s.output.findings.slice(0, 5).map(f => `<li>${esc(typeof f === 'string' ? f : (f.text || f.issue || JSON.stringify(f)))}</li>`).join('')}</ul>` : ''}` : ''}
        ${s.decision ? `<details><summary>Policy decision &amp; delegation</summary>
          <table><tbody>${s.decision.checks.map(c => `<tr><td>${c.passed ? '<span class="ok">✔</span>' : '<span class="bad">✖</span>'} ${esc(c.name)}</td><td>${esc(c.detail)}</td></tr>`).join('')}</tbody></table>
          ${s.delegation ? `<p class="hint">Scoped delegation: ${esc(s.delegation.scopes.join(', '))} · inherits user permissions: <b>${s.delegation.inherits_user_permissions}</b> · inherits upstream agent permissions: <b>${s.delegation.inherits_upstream_agent_permissions}</b></p>` : ''}
        </details>` : ''}
      </div>
    </div>`).join('');
  const recs = res && res.recommendations && res.recommendations.length
    ? `<h3>Recommendations</h3><ul>${res.recommendations.map(x => `<li>${esc(x.text)} <span class="hint">(${esc(x.agent)})</span></li>`).join('')}</ul>` : '';
  const mine = state.me && r.user === state.me.id;
  const open = ['running', 'awaiting_approval'].includes(r.status);
  const flags = (r.guardrail_flags || []).length ? `<p class="warn">Warning: Prompt-injection patterns flagged: ${esc(r.guardrail_flags.map(h => h.rule).join(', '))}</p>` : '';
  const origin = (r.rerun_of ? `<span class="hint">Re-run of ${esc(r.rerun_of)}. </span>` : '') + (r.template_id ? `<span class="hint">From template ${esc(r.template_id)}.</span>` : '');
  const tools = `${flags}<div class="row"><button type="button" onclick="downloadReport('${esc(r.id)}',this)">Download report (.md)</button>
    ${mine ? `<button type="button" onclick="rerunRun('${esc(r.id)}',this)">Re-run</button>` : ''}
    ${open && (mine || (state.me && state.me.role === 'Platform Admin')) ? `<button type="button" class="danger" onclick="cancelRun('${esc(r.id)}',this)">Cancel run</button>` : ''} ${origin}</div>`;
  $('#result').innerHTML = head + tools + `<h3>Execution plan</h3>` + steps + recs;
}

/* ---------- APPROVALS ---------- */
async function refreshApprovalCount() {
  try {
    const items = await api('/api/approvals');
    const c = $('#approvalCount'); c.textContent = items.length; c.hidden = items.length === 0;
    return items;
  } catch { return []; }
}

async function loadApprovals() {
  const items = await refreshApprovalCount();
  $('#selectAll').checked = false; syncBulk();
  $('#approvalUpdated').textContent = `Updated ${new Date().toLocaleTimeString()}`;
  $('#approvalsList').innerHTML = items.length ? items.map(x => `
    <article class="card approval">
      <input type="checkbox" class="pick" data-run="${esc(x.run_id)}" data-agent="${esc(x.agent_id)}" aria-label="Select ${esc(x.agent_name)} approval">${badge('awaiting_approval')} <span class="badge">${esc(x.data_classification)}</span>
      <h3>${esc(x.agent_name)}</h3>
      <p><b>Requested by:</b> ${esc(x.requested_by)} (${esc(x.requester_role)})</p>
      <p><b>Intent:</b> ${esc(x.intent)}</p>
      <p><b>Input:</b> <span class="hint">${esc(x.input_preview || '—')}</span></p>
      <p><b>Resources:</b> ${esc(x.required_resources.join(', '))} · <b>Cost:</b> ${money(x.cost_per_call)}</p>
      <p class="hint">Run ${esc(x.run_id)} · ${esc(x.created)}</p>
      ${x.due ? `<p class="${x.overdue ? 'bad' : 'hint'}">${x.overdue ? 'Overdue' : 'Due'} ${esc(x.due)}${x.escalated ? ' · escalated' : ''}</p>` : ''}
      <div class="row">
        <button class="approve" type="button" onclick="decide('${esc(x.run_id)}','${esc(x.agent_id)}',true,this)">Approve &amp; continue</button>
        <button class="danger" type="button" onclick="decide('${esc(x.run_id)}','${esc(x.agent_id)}',false,this)">Reject</button>
      </div>
    </article>`).join('')
    : `<div class="empty">No approvals waiting for you.<br>To create one: <b>Ask</b> tab → sample “Finance review” (as Arjun Mehta) or “KYC onboarding check” (as Meera Collins) → <b>Compose &amp; run</b>.</div>`;
}
$('#approvalBtn').onclick = () => busy($('#approvalBtn'), loadApprovals);

function askComment(approve) {
  const c = prompt(approve ? 'Approve this agent execution?\nOptional comment for the audit log:' : 'Reject this agent execution.\nReason (required, recorded in the audit log):', '');
  if (c === null) return null;
  if (!approve && c.trim().length < 3) { toast('A rejection reason of at least 3 characters is required.'); return null; }
  return c.trim();
}
async function decide(runId, agentId, approve, btn) {
  const comment = askComment(approve); if (comment === null) return;
  await busy(btn, async () => {
    const r = await api(`/api/runs/${encodeURIComponent(runId)}/decision`, { method: 'POST', body: JSON.stringify({ agent_id: agentId, approve, comment }) });
    toast(approve ? `Approved. Run is now: ${r.status}` : 'Rejected. The agent did not run.');
    if (state.lastRunId === runId) renderRun(r);
    await loadApprovals();
  });
}
window.decide = decide; window.showTab = showTab;

/* ---------- MARKETPLACE ---------- */
function agentCard(a, score) {
  return `<article class="card">
    ${badge(a.status)} ${a.suspended ? badge('blocked').replace('blocked', 'suspended') : ''} ${a.requires_approval ? badge('awaiting_approval').replace('awaiting approval', 'needs approval') : ''}
    <h3>${esc(a.name)}</h3>
    <p class="hint">${esc(a.provider)} · v${esc(a.version)} · ${esc(a.data_classification)}${a.rating ? ` · ★ ${a.rating}` : ''}${score != null ? ` · relevance ${(score * 100).toFixed(0)}%` : ''}</p>
    <p>${esc(a.description)}</p>
    <p class="${a.access.allowed ? 'ok' : 'bad'}">${a.access.allowed ? '✔ You can use this agent' : '✖ ' + esc(a.access.reason)}</p>
    <button type="button" onclick="openAgent('${esc(a.id)}')">Details</button>
  </article>`;
}
function filterQuery() {
  const p = new URLSearchParams();
  [['provider', '#fProvider'], ['status', '#fStatus'], ['classification', '#fClass'], ['requires_approval', '#fApproval'], ['usable', '#fUsable'], ['sort', '#fSort']]
    .forEach(([k, sel]) => { if ($(sel).value) p.set(k, $(sel).value); });
  return p.toString();
}
async function loadAgents() {
  const list = await api(`/api/agents?${filterQuery()}`);
  if (!filterQuery().replace(/sort=\w+/, '')) state.agents = list;
  else if (!state.agents.length) state.agents = await api('/api/agents');
  $('#agents').innerHTML = list.length ? list.map(a => agentCard(a)).join('') : '<div class="empty">No agents match these filters.</div>';
  fillSimulator();
}
async function loadFacets() {
  try {
    const f = await api('/api/agents/facets');
    const fill = (sel, obj, label) => { $(sel).innerHTML = `<option value="">${label}</option>` + Object.entries(obj).map(([k, n]) => `<option value="${esc(k)}">${esc(k)} (${n})</option>`).join(''); };
    fill('#fProvider', f.provider, 'All providers'); fill('#fStatus', f.status, 'All statuses'); fill('#fClass', f.classification, 'All classifications');
  } catch (e) { /* not signed in yet */ }
}
['#fProvider', '#fStatus', '#fClass', '#fApproval', '#fUsable', '#fSort'].forEach(sel => $(sel).addEventListener('change', () => loadAgents().catch(e => toast(e.message))));
$('#showAll').onclick = () => busy($('#showAll'), loadAgents);
$('#search').onclick = () => busy($('#search'), async () => {
  const q = $('#query').value.trim();
  if (q.length < 2) return loadAgents();
  const d = await api('/api/discover', { method: 'POST', body: JSON.stringify({ query: q }) });
  $('#agents').innerHTML = d.results.length ? d.results.map(r => agentCard(r.agent, r.score)).join('') : '<div class="empty">No matching agents.</div>';
});
$('#query').addEventListener('keydown', e => { if (e.key === 'Enter') $('#search').click(); });

async function openAgent(id) {
  try {
    const [a, fb, cert] = await Promise.all([api(`/api/agents/${encodeURIComponent(id)}`), api(`/api/agents/${encodeURIComponent(id)}/feedback`),
      api(`/api/agents/${encodeURIComponent(id)}/certification`)]);
    const canEdit = state.me && ['Agent Owner', 'Platform Admin'].includes(state.me.role);
    const isAdmin = state.me && state.me.role === 'Platform Admin';
    const LC = ['Experimental', 'Registered', 'Validated', 'Certified', 'Production'];
    const next = LC[LC.indexOf(a.status) + 1];
    $('#agentDetail').innerHTML = `<div class="card" style="margin-top:1rem">
      <h3>${esc(a.name)} ${badge(a.status)} ${a.suspended ? badge('blocked').replace('blocked', 'suspended') : ''}</h3>
      <p class="hint">User rating: ${fb.average != null ? `${fb.average}/5 from ${fb.count} rating(s)` : 'no ratings yet'}</p>
      <p>${esc(a.description)}</p>
      <p><b>Owner:</b> ${esc(a.owner)} · <b>Roles:</b> ${esc(a.allowed_roles.join(', '))} · <b>Regions:</b> ${esc(a.regions.join(', '))} · <b>Resources:</b> ${esc(a.required_resources.join(', '))}</p>
      <p><b>Cost/call:</b> ${money(a.cost_per_call)} · <b>Requires approval:</b> ${a.requires_approval ? 'Yes' : 'No'} · <b>Quality:</b> ${a.quality_score ?? 'n/a'} · <b>Success:</b> ${a.success_rate ?? 'n/a'}%</p>
      <table><thead><tr><th>Policy check for you</th><th>Detail</th></tr></thead><tbody>
      ${a.policy_checks.map(c => `<tr><td>${c.passed ? '<span class="ok">✔</span>' : '<span class="bad">✖</span>'} ${esc(c.name)}</td><td>${esc(c.detail)}</td></tr>`).join('')}</tbody></table>
      <details ${cert.passed ? '' : 'open'}><summary>Certification checklist: ${cert.passed ? '<span class="ok">blocking checks pass</span>' : '<span class="bad">blocking checks fail</span>'}${cert.advisories.length ? ` · ${cert.advisories.length} advisory` : ''}</summary>
        <table><tbody>${cert.checks.map(c => `<tr><td>${c.passed ? '<span class="ok">✔</span>' : c.blocking ? '<span class="bad">✖</span>' : '<span class="warn">!</span>'} ${esc(c.name)}${c.blocking ? '' : ' <span class="hint">(advisory)</span>'}</td><td>${esc(c.detail)}</td></tr>`).join('')}</tbody></table></details>
      ${canEdit ? `<details><summary>Edit metadata</summary>
        <p class="hint">Changing roles, regions, resources, classification or approval on a Certified/Production agent sends it back to <b>Validated</b> for re-certification.</p>
        <form id="editForm" data-id="${esc(a.id)}" class="grid2">
          <label>Description <input name="description" value="${esc(a.description)}"></label>
          <label>Keywords (comma separated) <input name="keywords" value="${esc(a.keywords.join(', '))}"></label>
          <label>Allowed roles <input name="allowed_roles" value="${esc(a.allowed_roles.join(', '))}"></label>
          <label>Regions <input name="regions" value="${esc(a.regions.join(', '))}"></label>
          <label>Cost per call <input name="cost_per_call" type="number" step="0.01" min="0" value="${a.cost_per_call}"></label>
          <label>Classification <select name="data_classification">${['Public', 'Internal', 'Confidential', 'Restricted'].map(c => `<option ${c === a.data_classification ? 'selected' : ''}>${c}</option>`).join('')}</select></label>
          <label class="check"><input type="checkbox" name="requires_approval" ${a.requires_approval ? 'checked' : ''}> Requires human approval</label>
          <div><button class="primary" type="submit">Save changes</button></div>
        </form></details>` : ''}
      <div class="row">
        <button class="primary" type="button" onclick="tryAgent('${esc(a.id)}',this)">Try it</button>
        ${isAdmin ? `<button type="button" class="${a.suspended ? '' : 'danger'}" onclick="toggleSuspend('${esc(a.id)}',${!a.suspended},this)">${a.suspended ? 'Resume agent' : 'Kill switch: suspend'}</button>` : ''}
        ${isAdmin && next ? `<button type="button" onclick="promote('${esc(a.id)}','${next}',this)">Promote → ${next}</button>` : ''}
        ${!isAdmin ? '<span class="hint">Lifecycle promotion requires Platform Admin (Sam Carter).</span>' : ''}
      </div></div>`;
    const ef = $('#editForm');
    if (ef) ef.onsubmit = ev => saveAgent(ev, a);
    $('#agentDetail').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (e) { toast(e.message); }
}
async function tryAgent(id, btn) {
  await busy(btn, async () => {
    const r = await api('/api/runs', { method: 'POST', body: JSON.stringify({ intent: `Manual invocation of ${id}`, input_text: $('#input').value || 'Sample input', agent_ids: [id] }) });
    showTab('ask'); renderRun(r); await refreshApprovalCount();
  });
}
async function promote(id, target, btn) {
  await busy(btn, async () => {
    await api(`/api/agents/${encodeURIComponent(id)}/lifecycle`, { method: 'POST', body: JSON.stringify({ target }) });
    toast(`Promoted to ${target}`); await loadAgents(); await openAgent(id);
  });
}
Object.assign(window, { openAgent, tryAgent, promote });

/* ---------- REGISTER ---------- */
$('#regForm').onsubmit = async e => {
  e.preventDefault();
  const f = new FormData(e.target);
  const list = k => String(f.get(k) || '').split(',').map(x => x.trim()).filter(Boolean);
  const body = {
    id: String(f.get('id') || '').trim(), name: String(f.get('name') || '').trim(), provider: f.get('provider'),
    owner: String(f.get('owner') || '').trim(), description: String(f.get('description') || '').trim(),
    data_classification: f.get('data_classification'), cost_per_call: Number(f.get('cost_per_call') || 0.02),
    capabilities: list('capabilities'), keywords: list('keywords'), requires_approval: f.get('requires_approval') === 'on'
  };
  const errs = [];
  if (!/^[a-z0-9][a-z0-9-]{2,40}$/.test(body.id)) errs.push('Agent ID: 3–41 lowercase letters, digits or hyphens.');
  ['name', 'owner', 'description'].forEach(k => { if (!body[k]) errs.push(`${k[0].toUpperCase() + k.slice(1)} is required.`); });
  if (!body.capabilities.length) errs.push('Add at least one capability.');
  $('#regErrors').innerHTML = errs.map(esc).join('<br>');
  if (errs.length) return;
  const btn = e.target.querySelector('button[type=submit]');
  await busy(btn, async () => {
    const a = await api('/api/agents', { method: 'POST', body: JSON.stringify(body) });
    $('#regOut').innerHTML = `<div class="card"><b>${esc(a.name)}</b> registered ${badge(a.status)}. It is blocked until a Platform Admin promotes it to Certified/Production (Marketplace → Details).</div>`;
    e.target.reset(); state.agents = [];
  });
};

/* ---------- GOVERNANCE ---------- */
function fillSimulator() {
  $('#simUser').innerHTML = state.users.map(u => `<option value="${esc(u.id)}">${esc(u.name)} · ${esc(u.role)}</option>`).join('');
  if (state.agents.length) $('#simAgent').innerHTML = state.agents.map(a => `<option value="${esc(a.id)}">${esc(a.name)}</option>`).join('');
}
$('#simBtn').onclick = () => busy($('#simBtn'), async () => {
  if (!state.agents.length) { state.agents = await api('/api/agents'); fillSimulator(); }
  const d = await api('/api/policy/simulate', { method: 'POST', body: JSON.stringify({ user_id: $('#simUser').value, agent_id: $('#simAgent').value }) });
  $('#simOut').innerHTML = `<div class="card"><b>${esc(d.user)}</b> (${esc(d.role)}) → <b>${esc(d.agent)}</b>: ${d.allowed ? badge('allow') : badge('deny')}
    <table><tbody>${d.checks.map(c => `<tr><td>${c.passed ? '<span class="ok">✔</span>' : '<span class="bad">✖</span>'} ${esc(c.name)}</td><td>${esc(c.detail)}</td></tr>`).join('')}</tbody></table></div>`;
});

async function loadAudit() {
  try {
    if (!state.agents.length) { state.agents = await api('/api/agents'); fillSimulator(); }
    const rows = (await api('/api/audit?limit=200')).filter(x => !$('#auditFilter').value || x.action === $('#auditFilter').value);
    $('#audit').innerHTML = rows.length ? `<div class="tablewrap"><table><thead><tr><th>Time (UTC)</th><th>User</th><th>Action</th><th>Agent</th><th>Decision</th><th>Outcome / reason</th></tr></thead><tbody>
      ${rows.map(x => `<tr><td>${esc(x.ts)}</td><td>${esc(x.user_name || x.user)}</td><td>${esc(x.action)}</td><td>${esc(x.agent_name || '—')}</td><td>${badge(x.decision)}</td><td>${esc(x.outcome || '')}${x.reason ? ` <span class="hint">· ${esc(x.reason)}</span>` : ''}</td></tr>`).join('')}
      </tbody></table></div>` : '<div class="empty">No audit events yet.</div>';
  } catch (e) { toast(e.message); }
}
$('#auditBtn').onclick = () => busy($('#auditBtn'), loadAudit);
$('#auditFilter').onchange = loadAudit;

/* ---------- OBSERVABILITY ---------- */
async function loadMetrics() {
  try {
    const d = await api('/api/metrics');
    $('#metrics').innerHTML = d.kpis.map(k => `<article class="card">${k.met ? badge('completed').replace('completed', 'target met') : badge('pending').replace('pending', 'target pending')}
      <h3>${esc(k.name)}</h3><p style="font-size:1.6rem;margin:.2rem 0"><b>${esc(k.value ?? '—')}</b></p><p class="hint">Target ${esc(k.target)}</p></article>`).join('');
    const t = d.totals;
    $('#metricsTables').innerHTML = `<p class="hint">Attempts ${t.invocation_attempts} · allowed ${t.allowed} · denied ${t.denied} · runs ${t.runs} · cost ${money(t.total_cost_usd)} · tokens ${t.total_tokens}</p>
      ${d.by_agent.length ? `<div class="tablewrap"><table><thead><tr><th>Agent</th><th>Calls</th><th>Cost</th><th>Tokens</th><th>Avg latency (s, simulated)</th></tr></thead><tbody>
      ${d.by_agent.map(b => `<tr><td>${esc(b.agent)}</td><td>${b.calls}</td><td>${money(b.cost)}</td><td>${b.tokens}</td><td>${b.avg_latency_sec}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">Run some workflows to populate per-agent metrics.</div>'}`;
  } catch (e) { toast(e.message); }
}
$('#metricsBtn').onclick = () => busy($('#metricsBtn'), loadMetrics);

/* ---------- init ---------- */
async function init() {
  state.users = await api('/api/users');
  $('#user').innerHTML = state.users.map(u => `<option value="${esc(u.id)}">${esc(u.name)} · ${esc(u.role)}</option>`).join('');
  const saved = localStorage.getItem('poc-user');
  if (saved && state.users.some(u => u.id === saved)) $('#user').value = saved;
  state.samples = await api('/api/samples');
  $('#sample').innerHTML = '<option value="">Choose a sample…</option>' + state.samples.map((s, i) => `<option value="${i}">${esc(s.label)}</option>`).join('');
  fillSimulator();
  await login();
  const tab = location.hash.slice(1);
  if (['ask', 'market', 'register', 'runs', 'approvals', 'admin', 'governance', 'observability'].includes(tab)) showTab(tab);
  setInterval(() => { refreshApprovalCount(); loadNotifications(); }, 15000);
  loadFacets();
  console.info('Enterprise Agentic Web UI', document.querySelector('meta[name=app-version]').content);
}
$('#user').onchange = () => login().catch(e => toast(e.message));
init().catch(e => toast(`Could not start UI: ${e.message}`));


/* ---------- v1.1: bulk approvals ---------- */
function picked() { return $$('#approvalsList .pick:checked').map(c => ({ run_id: c.dataset.run, agent_id: c.dataset.agent })); }
function syncBulk() { const n = picked().length; $('#bulkApprove').disabled = $('#bulkReject').disabled = n === 0;
  $('#bulkApprove').textContent = `Approve selected${n ? ` (${n})` : ''}`; $('#bulkReject').textContent = `Reject selected${n ? ` (${n})` : ''}`; }
$('#approvalsList').addEventListener('change', e => { if (e.target.classList.contains('pick')) syncBulk(); });
$('#selectAll').onchange = e => { $$('#approvalsList .pick').forEach(c => (c.checked = e.target.checked)); syncBulk(); };
async function bulk(approve, btn) {
  const items = picked(); if (!items.length) return;
  const comment = askComment(approve); if (comment === null) return;
  await busy(btn, async () => {
    const d = await api('/api/approvals/bulk', { method: 'POST', body: JSON.stringify({ items, approve, comment }) });
    const failed = d.results.filter(x => !x.ok);
    toast(`${d.decided} ${approve ? 'approved' : 'rejected'}${failed.length ? `, ${failed.length} failed: ${failed[0].error}` : ''}`);
    await loadApprovals();
  });
}
$('#bulkApprove').onclick = () => bulk(true, $('#bulkApprove'));
$('#bulkReject').onclick = () => bulk(false, $('#bulkReject'));

/* ---------- v1.1: run history ---------- */
async function loadRuns() {
  try {
    const f = $('#runsFilter').value;
    const rows = (await api('/api/runs')).filter(r => !f || r.status === f);
    $('#runsList').innerHTML = rows.length ? `<div class="tablewrap"><table><thead><tr><th>Created (UTC)</th><th>Requested by</th><th>Intent</th><th>Agents</th><th>Status</th><th></th></tr></thead><tbody>
      ${rows.map(r => `<tr><td>${esc(r.created)}</td><td>${esc(r.user_name)}</td><td>${esc(r.intent)}</td><td>${r.agents}</td><td>${badge(r.status)}</td>
      <td><button type="button" class="mini" onclick="openRun('${esc(r.id)}',this)">Open</button>
        ${state.me && r.user === state.me.id ? `<button type="button" class="mini" onclick="rerunRun('${esc(r.id)}',this)">Re-run</button>` : ''}
        ${['running', 'awaiting_approval'].includes(r.status) && state.me && (r.user === state.me.id || state.me.role === 'Platform Admin') ? `<button type="button" class="mini danger" onclick="cancelRun('${esc(r.id)}',this)">Cancel</button>` : ''}</td></tr>`).join('')}</tbody></table></div>`
      : '<div class="empty">No runs yet. Use the <b>Ask</b> tab to compose one.</div>';
  } catch (e) { toast(e.message); }
}
async function openRun(id, btn) { await busy(btn, async () => { const r = await api(`/api/runs/${encodeURIComponent(id)}`); showTab('ask'); renderRun(r); }); }
$('#runsBtn').onclick = () => busy($('#runsBtn'), loadRuns);
$('#runsFilter').onchange = loadRuns;

/* ---------- v1.1: feedback ---------- */
async function rate(runId, agentId, n, btn) {
  try {
    await api(`/api/runs/${encodeURIComponent(runId)}/feedback`, { method: 'POST', body: JSON.stringify({ agent_id: agentId, rating: n }) });
    Array.from(btn.parentElement.querySelectorAll('button')).forEach((b, i) => b.classList.toggle('on', i < n));
    toast(`Thanks - rated ${n}/5`);
  } catch (e) { toast(e.message); }
}

/* ---------- v1.1: downloads ---------- */
async function download(path, filename) {
  const r = await fetch(path, { headers: { Authorization: `Bearer ${state.token}` }, cache: 'no-store' });
  if (!r.ok) { const d = await r.json().catch(() => ({})); throw new Error(`${r.status}: ${d.detail || r.statusText}`); }
  const url = URL.createObjectURL(await r.blob());
  const a = Object.assign(document.createElement('a'), { href: url, download: filename }); document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function downloadReport(id, btn) { return busy(btn, () => download(`/api/runs/${encodeURIComponent(id)}/report`, `${id}-report.md`)); }
$('#auditExport').onclick = () => busy($('#auditExport'), () => download('/api/audit/export', 'audit-log.csv'));

/* ---------- v1.1: kill switch ---------- */
async function toggleSuspend(id, suspended, btn) {
  let reason = '';
  if (suspended) { reason = prompt('Suspend this agent for everyone. Reason (recorded in audit):', ''); if (reason === null) return; }
  await busy(btn, async () => {
    await api(`/api/agents/${encodeURIComponent(id)}/suspend`, { method: 'POST', body: JSON.stringify({ suspended, reason }) });
    toast(suspended ? 'Agent suspended. New invocations are blocked.' : 'Agent resumed.'); await loadAgents(); await openAgent(id);
  });
}
Object.assign(window, { rate, openRun, downloadReport, toggleSuspend });


/* =====================================================================
   v2.0 features 21-40
   ===================================================================== */
const list = v => String(v || '').split(',').map(x => x.trim()).filter(Boolean);

/* 23 notifications */
async function loadNotifications() {
  try {
    const d = await api('/api/notifications');
    $('#bellCount').textContent = d.unread; $('#bellCount').hidden = d.unread === 0;
    $('#notifList').innerHTML = d.items.length ? d.items.map(n => `<div class="notif ${n.read ? '' : 'unread'}">
      <b>${esc(n.title)}</b><br>${n.body ? `${esc(n.body)}<br>` : ''}<small>${esc(n.ts)} · ${esc(n.kind)}</small>
      ${n.link ? ` <a href="${esc(n.link)}" onclick="showTab('${esc(n.link.slice(1))}');$('#notifPanel').hidden=true;return false">Open</a>` : ''}</div>`).join('')
      : '<div class="hint">No notifications.</div>';
  } catch (e) { /* ignore */ }
}
$('#bell').onclick = () => { const p = $('#notifPanel'); p.hidden = !p.hidden; $('#bell').setAttribute('aria-expanded', String(!p.hidden)); if (!p.hidden) loadNotifications(); };
$('#markRead').onclick = async () => { await api('/api/notifications/read', { method: 'POST' }); loadNotifications(); };
document.addEventListener('keydown', e => { if (e.key === 'Escape') $('#notifPanel').hidden = true; });

/* 28 templates */
async function loadTemplates() {
  try {
    const keep = $('#templateSel').value;
    state.templates = await api('/api/templates');
    $('#templateSel').innerHTML = '<option value="">No template (auto-select agents)…</option>' +
      state.templates.map(t => `<option value="${esc(t.id)}">${esc(t.name)}${t.shared ? '' : ' (private)'} · ${t.agent_ids.length} agents</option>`).join('');
    if (keep && state.templates.some(x => x.id === keep)) $('#templateSel').value = keep;
  } catch (e) { /* ignore */ }
}
$('#templateSel').onchange = e => {
  const t = (state.templates || []).find(x => x.id === e.target.value);
  $('#templateHint').innerHTML = t ? `${esc(t.description || '')} <br><b>Agents:</b> ${esc(t.agent_ids.join(', '))} · used ${t.uses}× ${t.owner === state.me.id || state.me.role === 'Platform Admin' ? ` · <a href="#" onclick="deleteTemplate('${esc(t.id)}');return false">delete</a>` : ''}` : 'Templates run a fixed, reviewed list of agents.';
  if (t) $('#intent').value = t.intent;
};
async function deleteTemplate(id) {
  if (!confirm('Delete this template?')) return;
  try { await api(`/api/templates/${encodeURIComponent(id)}`, { method: 'DELETE' }); toast('Template deleted'); $('#templateSel').value = ''; await loadTemplates(); } catch (e) { toast(e.message); }
}
$('#saveTemplate').onclick = () => busy($('#saveTemplate'), async () => {
  const agents = state.lastRunId ? (await api(`/api/runs/${state.lastRunId}`)).steps.map(s => s.agent_id) : null;
  if (!agents || !agents.length) return toast('Run a workflow first, then save its agents as a template.');
  const name = prompt('Template name:', $('#intent').value.slice(0, 60)); if (!name) return;
  const shared = confirm('Share this template with everyone? (Cancel = private)');
  await api('/api/templates', { method: 'POST', body: JSON.stringify({ name, intent: $('#intent').value || name, agent_ids: agents, shared }) });
  toast('Template saved'); await loadTemplates();
});
// Override run: use template when selected
const _runClick = $('#run').onclick;
$('#run').onclick = () => {
  const tid = $('#templateSel').value;
  if (!tid) return _runClick();
  return busy($('#run'), async () => {
    $('#runStatus').textContent = 'Running template…';
    const r = await api(`/api/templates/${encodeURIComponent(tid)}/run`, { method: 'POST', body: JSON.stringify({ input_text: $('#input').value }) });
    renderRun(r); await refreshApprovalCount(); loadTemplates();
  });
};

/* 25 dry run */
$('#dryRun').onclick = () => busy($('#dryRun'), async () => {
  const tid = $('#templateSel').value, t = (state.templates || []).find(x => x.id === tid);
  const intent = $('#intent').value.trim(); if (intent.length < 2) return toast('Enter an intent first.');
  const d = await api('/api/runs/plan', { method: 'POST', body: JSON.stringify({ intent, agent_ids: t ? t.agent_ids : null }) });
  $('#previewOut').innerHTML = `<div class="card"><b>Dry run</b> - nothing executed or charged.
    Estimated cost <b>${money(d.estimated_cost_usd)}</b> of ${money(d.remaining_budget_usd)} remaining · approvals needed: <b>${d.approvals_needed}</b>
    <div class="tablewrap"><table><thead><tr><th>Agent</th><th>Would run?</th><th>Approval</th><th>PII masked</th><th>Cost</th></tr></thead><tbody>
    ${d.steps.map(s => `<tr><td>${esc(s.agent_name)}</td><td>${s.would_run ? '<span class="ok">Yes</span>' : `<span class="bad">No - ${esc(s.reason)}</span>`}</td>
      <td>${s.requires_approval ? badge('awaiting_approval').replace('awaiting approval', 'required') : '—'}</td><td>${s.pii_redaction ? 'Yes' : 'No'}</td><td>${money(s.cost_per_call)}</td></tr>`).join('')}
    </tbody></table></div></div>`;
});

/* 29/30 live guardrail hint */
let guardTimer;
function guardCheck() {
  clearTimeout(guardTimer);
  guardTimer = setTimeout(async () => {
    const text = `${$('#intent').value}\n${$('#input').value}`;
    if (text.trim().length < 8) { $('#guardWarn').innerHTML = ''; return; }
    try {
      const d = await api('/api/guardrails/check', { method: 'POST', body: JSON.stringify({ text }) });
      const pii = Object.entries(d.pii).map(([k, v]) => `${v} ${k}`).join(', ');
      $('#guardWarn').innerHTML = (d.injection.length ? `<p class="bad">Warning: Possible prompt injection (${esc(d.injection.map(h => h.rule).join(', '))}). Guard mode: <b>${esc(d.mode)}</b>${d.mode === 'block' ? ' - this run will be refused.' : ''}</p>` : '') +
        (pii ? `<p class="hint">Detected ${esc(pii)}. These are masked before agents cleared only for Public/Internal data.</p>` : '');
    } catch (e) { /* ignore */ }
  }, 500);
}
$('#input').addEventListener('input', guardCheck); $('#intent').addEventListener('input', guardCheck);

/* 26/27 cancel + rerun */
async function cancelRun(id, btn) {
  const reason = prompt('Cancel this run? Remaining steps will not execute.\nReason (optional):', ''); if (reason === null) return;
  await busy(btn, async () => {
    const r = await api(`/api/runs/${encodeURIComponent(id)}/cancel`, { method: 'POST', body: JSON.stringify({ reason }) });
    toast('Run cancelled'); if (state.lastRunId === id) renderRun(r); refreshApprovalCount(); if (!$('#runs').classList.contains('hidden')) loadRuns();
  });
}
async function rerunRun(id, btn) {
  await busy(btn, async () => {
    const r = await api(`/api/runs/${encodeURIComponent(id)}/rerun`, { method: 'POST' });
    showTab('ask'); renderRun(r); toast(`New run ${r.id} started`); refreshApprovalCount();
  });
}

/* 38 edit agent */
async function saveAgent(ev, a) {
  ev.preventDefault();
  const f = new FormData(ev.target);
  const body = { description: f.get('description'), keywords: list(f.get('keywords')), allowed_roles: list(f.get('allowed_roles')),
    regions: list(f.get('regions')), cost_per_call: Number(f.get('cost_per_call')), data_classification: f.get('data_classification'),
    requires_approval: f.get('requires_approval') === 'on' };
  try {
    const r = await api(`/api/agents/${encodeURIComponent(a.id)}`, { method: 'PATCH', body: JSON.stringify(body) });
    toast(r.changed.length ? `Saved: ${r.changed.join(', ')}${r.recertification_required ? ' - re-certification required' : ''}` : 'No changes');
    await loadAgents(); await openAgent(a.id);
  } catch (e) { toast(e.message); }
}

/* 31 audit integrity */
$('#verifyAudit').onclick = () => busy($('#verifyAudit'), async () => {
  const v = await api('/api/audit/verify');
  $('#verifyOut').innerHTML = v.valid ? `<p class="ok">✔ Audit chain intact: ${v.events} events, head ${esc(v.head.slice(0, 16))}…</p>`
    : `<p class="bad">✖ Audit chain broken at event #${v.broken_at} (${esc(v.event_id)}). Investigate tampering.</p>`;
});

/* 36 chargeback */
async function loadChargeback() {
  try {
    const d = await api(`/api/reports/chargeback?group_by=${$('#cbGroup').value}`);
    $('#chargeback').innerHTML = `<p class="hint">Scope: ${esc(d.scope)} · total ${money(d.total_cost_usd)} (simulated costs)</p>` + (d.rows.length ?
      `<div class="tablewrap"><table><thead><tr><th>${esc(d.group_by)}</th><th>Calls</th><th>Runs</th><th>Tokens</th><th>Cost</th></tr></thead><tbody>
      ${d.rows.map(r => `<tr><td>${esc(r.group)}</td><td>${r.calls}</td><td>${r.runs}</td><td>${r.tokens}</td><td>${money(r.cost_usd)}</td></tr>`).join('')}</tbody></table></div>`
      : '<div class="empty">No completed agent calls yet.</div>');
  } catch (e) { toast(e.message); }
}
$('#cbGroup').onchange = loadChargeback;

/* Admin console: 21 22 29 30 32 34 24 33 40 */
async function loadAdmin() {
  const isAdmin = state.me && state.me.role === 'Platform Admin';
  $('#adminDenied').hidden = isAdmin; $('#adminBody').hidden = !isAdmin;
  if (!isAdmin) return;
  try {
    const [cfg, users, health] = await Promise.all([api('/api/admin/settings'), api('/api/admin/users'), api('/api/admin/health')]);
    const form = $('#settingsForm');
    Object.entries(cfg.settings).forEach(([k, v]) => { const el = form.elements[k]; if (!el) return; if (el.type === 'checkbox') el.checked = v; else el.value = v; });
    const p = cfg.persistence;
    $('#persistInfo').textContent = `Persistence ${p.enabled ? 'ON' : 'off'} · ${p.file}${p.last_saved ? ` · last saved ${p.last_saved}` : ''}${p.error ? ` · error: ${p.error}` : ''}`;
    $('#budgets').innerHTML = `<div class="tablewrap"><table><thead><tr><th>User</th><th>Role</th><th>Spent</th><th>Budget</th><th>Used</th><th></th></tr></thead><tbody>
      ${users.map(u => `<tr><td>${esc(u.name)}</td><td>${esc(u.role)}</td><td>${money(u.spent_usd)}</td>
        <td><input type="number" min="0" step="0.5" value="${u.budget_usd}" id="bud-${esc(u.id)}" style="width:6rem" aria-label="Budget for ${esc(u.name)}"></td>
        <td class="${u.used_pct >= 80 ? 'bad' : ''}">${u.used_pct ?? '—'}%</td><td><button type="button" class="mini" onclick="setBudget('${esc(u.id)}',this)">Save</button></td></tr>`).join('')}</tbody></table></div>`;
    $('#health').innerHTML = `<div class="tablewrap"><table><thead><tr><th>Agent</th><th>Circuit</th><th>Failures</th><th>Fault rate</th><th>Last error</th><th></th></tr></thead><tbody>
      ${health.map(h => `<tr><td>${esc(h.agent)}</td><td>${badge(h.state === 'open' ? 'blocked' : h.state === 'half_open' ? 'pending' : 'completed').replace(/blocked|pending|completed/, h.state.replace('_', '-'))}</td>
        <td>${h.failures}</td><td><select id="fault-${esc(h.agent_id)}" aria-label="Fault rate for ${esc(h.agent)}">${[0, 0.25, 0.5, 1].map(r => `<option value="${r}" ${r === h.fault_rate ? 'selected' : ''}>${r * 100}%</option>`).join('')}</select></td>
        <td class="hint">${esc(h.last_error || '')}</td><td><button type="button" class="mini" onclick="setFault('${esc(h.agent_id)}',this)">Apply</button>
        ${h.state !== 'closed' ? `<button type="button" class="mini" onclick="resetBreaker('${esc(h.agent_id)}',this)">Reset</button>` : ''}</td></tr>`).join('')}</tbody></table></div>`;
  } catch (e) { toast(e.message); }
}
$('#saveSettings').onclick = () => busy($('#saveSettings'), async () => {
  const f = $('#settingsForm').elements, body = {};
  ['segregation_of_duties', 'pii_redaction'].forEach(k => (body[k] = f[k].checked));
  body.injection_guard = f.injection_guard.value;
  ['approval_sla_minutes', 'budget_alert_ratio'].forEach(k => (body[k] = Number(f[k].value)));
  ['run_rate_limit_per_min', 'breaker_threshold', 'max_retries'].forEach(k => (body[k] = parseInt(f[k].value, 10)));
  await api('/api/admin/settings', { method: 'PUT', body: JSON.stringify(body) });
  toast('Settings saved'); loadAdmin();
});
$('#snapshotBtn').onclick = () => busy($('#snapshotBtn'), async () => { const d = await api('/api/admin/snapshot', { method: 'POST' }); toast(`Saved to ${d.saved}`); loadAdmin(); });
async function setBudget(id, btn) {
  await busy(btn, async () => { await api(`/api/admin/users/${id}/budget`, { method: 'PUT', body: JSON.stringify({ budget_usd: Number($(`#bud-${id}`).value) }) }); toast('Budget updated'); loadAdmin(); });
}
async function setFault(id, btn) {
  await busy(btn, async () => { await api(`/api/admin/agents/${id}/fault`, { method: 'PUT', body: JSON.stringify({ rate: Number($(`#fault-${id}`).value) }) }); toast('Fault injection updated'); loadAdmin(); });
}
async function resetBreaker(id, btn) {
  await busy(btn, async () => { await api(`/api/admin/agents/${id}/reset-breaker`, { method: 'POST' }); toast('Circuit reset'); loadAdmin(); });
}
async function purge(dry, btn) {
  const days = parseInt($('#purgeDays').value, 10);
  if (!dry && !confirm(`Permanently delete closed runs older than ${days} days? Audit events are kept.`)) return;
  await busy(btn, async () => {
    const d = await api('/api/admin/purge', { method: 'POST', body: JSON.stringify({ older_than_days: days, dry_run: dry }) });
    $('#purgeOut').textContent = `${dry ? 'Would delete' : 'Deleted'} ${d.runs} run(s) created before ${d.cutoff}. ${d.note}`;
  });
}
$('#purgePreview').onclick = () => purge(true, $('#purgePreview'));
$('#purgeRun').onclick = () => purge(false, $('#purgeRun'));

Object.assign(window, { cancelRun, rerunRun, deleteTemplate, setBudget, setFault, resetBreaker });
