"""Agent Orchestration layer: intent -> discovery -> plan -> guardrails -> governed execution -> unified result."""
from datetime import datetime, timedelta, timezone

from . import guardrails, registry, resilience, security, settings, telemetry as T
from .adapters import get_adapter

MAX_AGENTS = 6
OPEN_STATES = ("running", "awaiting_approval")


class GuardrailBlocked(Exception):
    def __init__(self, hits):
        super().__init__("Input blocked by prompt-injection guard: " + ", ".join(sorted({h["rule"] for h in hits})))
        self.hits = hits


def plan(intent: str, agent_ids=None):
    if agent_ids:
        picks = [{"agent_id": a, "score": 1.0, "matched_terms": ["manually selected"]} for a in agent_ids if a in registry.AGENTS]
    else:
        found = registry.discover(intent)
        if not found:
            return []
        top = found[0]["score"]
        picks = [f for f in found if f["score"] >= max(0.15, 0.2 * top)][:MAX_AGENTS]
    picks.sort(key=lambda p: (registry.AGENTS[p["agent_id"]]["stage"], -p["score"]))
    steps = []
    for i, p in enumerate(picks):
        a = registry.AGENTS[p["agent_id"]]
        steps.append({"idx": i, "agent_id": a["id"], "agent_name": a["name"], "provider": a["provider"], "version": a["version"],
                      "stage": a["stage"], "relevance": p["score"], "matched_terms": p["matched_terms"], "status": "pending",
                      "approved": False, "decision": None, "output": None, "metrics": None, "delegation": None, "note": None,
                      "attempts": 0, "redactions": {}})
    return steps


def dry_run(user, intent, agent_ids=None):
    """Feature 25: show the plan, each step's policy outcome and estimated cost without executing or charging."""
    steps = plan(intent, agent_ids)
    spent = T.spent(user["id"])
    out, est = [], 0.0
    for s in steps:
        a = registry.AGENTS[s["agent_id"]]
        ev = security.evaluate(user, a, spent + est)
        if ev["allowed"]:
            est += a["cost_per_call"]
        out.append({"agent_id": a["id"], "agent_name": a["name"], "provider": a["provider"], "relevance": s["relevance"],
                    "would_run": ev["allowed"], "reason": ev["reason"], "requires_approval": a["requires_approval"],
                    "pii_redaction": settings.SETTINGS["pii_redaction"] and a["data_classification"] in guardrails.REDACT_FOR,
                    "cost_per_call": a["cost_per_call"], "checks": ev["checks"]})
    return {"intent": intent, "steps": out, "estimated_cost_usd": round(est, 4),
            "approvals_needed": sum(1 for x in out if x["would_run"] and x["requires_approval"]),
            "remaining_budget_usd": round(user["budget_usd"] - spent, 4)}


def create_run(user, intent, input_text, agent_ids=None, template_id=None, rerun_of=None):
    mode = settings.SETTINGS["injection_guard"]
    hits = guardrails.detect_injection(intent, input_text) if mode != "off" else []
    if hits and mode == "block":
        T.audit(action="guardrail", user=user["id"], user_name=user["name"], role=user["role"], decision="deny",
                outcome="blocked", reason="; ".join(f"{h['rule']}: '{h['match']}'" for h in hits))
        raise GuardrailBlocked(hits)
    run_id = T.new_id("run")
    steps = plan(intent, agent_ids)
    run = {"id": run_id, "user": user["id"], "user_name": user["name"], "role": user["role"], "intent": intent,
           "input_text": input_text, "created": T.now(), "status": "running", "steps": steps, "result": None,
           "template_id": template_id, "rerun_of": rerun_of, "guardrail_flags": hits}
    if hits:
        T.audit(action="guardrail", run_id=run_id, user=user["id"], user_name=user["name"], role=user["role"], decision="allow",
                outcome="flagged", reason="; ".join(h["rule"] for h in hits))
    with T.LOCK:
        T.RUNS[run_id] = run
    if not steps:
        run["status"] = "failed"
        run["result"] = {"headline": "No matching agents were found for this intent.", "sections": [], "blocked": [], "totals": {}}
        return run
    advance(run, user)
    return run


def _upstream(run):
    return {s["agent_id"]: s["output"] for s in run["steps"] if s["status"] == "completed" and s["output"]}


def _record(user, agent, run, step, decision, outcome, res=None, reason=None):
    with T.LOCK:
        T.ATTEMPTS["count"] += 1
        T.audit(action="invoke", run_id=run["id"], user=user["id"], user_name=user["name"], role=user["role"],
                agent_id=agent["id"], agent_name=agent["name"], agent_version=agent["version"], provider=agent["provider"],
                decision=decision, outcome=outcome, reason=reason, resources=agent["required_resources"],
                model=(res or {}).get("model") or agent["models"][0], tokens=((res or {}).get("tokens_in", 0) + (res or {}).get("tokens_out", 0)),
                cost_usd=(res or {}).get("cost_usd", 0.0), latency_sec=(res or {}).get("simulated_latency_sec", 0.0),
                attempts=step.get("attempts", 0), redactions=step.get("redactions") or None,
                delegation=step.get("delegation"), checks=step["decision"]["checks"] if step.get("decision") else [])


def _due(minutes):
    return (datetime.now(timezone.utc) + timedelta(minutes=minutes)).isoformat(timespec="seconds")


def _budget_alert(user, before, after):
    ratio = settings.SETTINGS["budget_alert_ratio"]
    limit = user["budget_usd"] * ratio
    if before < limit <= after:
        T.notify([user["id"]], "budget", f"You have used {int(ratio * 100)}% of your agent budget",
                 f"${after:.2f} of ${user['budget_usd']:.2f} spent.")


def advance(run, user):
    for step in run["steps"]:
        if step["status"] != "pending":
            continue
        agent = registry.AGENTS[step["agent_id"]]
        decision = security.evaluate(user, agent, T.spent(user["id"]))
        step["decision"] = decision
        if not decision["allowed"]:
            step["status"], step["note"] = "blocked", decision["reason"]
            _record(user, agent, run, step, "deny", "blocked", reason=decision["reason"])
            continue
        if agent["requires_approval"] and not step["approved"]:
            step["status"], step["note"] = "awaiting_approval", "Human approval required before this agent runs"
            step["approval_due"], step["escalated"] = _due(settings.SETTINGS["approval_sla_minutes"]), False
            run["status"] = "awaiting_approval"
            T.audit(action="approval_requested", run_id=run["id"], user=user["id"], user_name=user["name"], role=user["role"],
                    agent_id=agent["id"], agent_name=agent["name"], decision="pending", outcome="waiting", reason=step["note"])
            T.notify(security.approvers(run), "approval", f"Approval needed: {agent['name']}",
                     f"{run['user_name']}: {run['intent'][:80]}", f"#approvals")
            return run
        step["delegation"] = security.delegation_for(user, agent, run["id"])
        text = run["input_text"]
        if settings.SETTINGS["pii_redaction"] and agent["data_classification"] in guardrails.REDACT_FOR:
            text, step["redactions"] = guardrails.redact(text)
        adapter = get_adapter(agent["provider"])
        try:
            res, step["attempts"] = resilience.call(agent, lambda: adapter.invoke(agent, text, _upstream(run)))
        except resilience.ProviderError as e:
            step["attempts"] = settings.SETTINGS["max_retries"] + 1
            step["status"], step["note"] = "failed", f"Provider error: {e}"
            _record(user, agent, run, step, "allow", "failure", reason=str(e))
            continue
        step["output"], step["status"] = res.pop("output"), "completed"
        step["metrics"] = res
        before = T.spent(user["id"])
        T.charge(user["id"], res["cost_usd"])
        _budget_alert(user, before, T.spent(user["id"]))
        _record(user, agent, run, step, "allow", "success", res)
    _finalize(run)
    return run


def decide(run, user, agent_id, approve: bool, comment: str = ""):
    why = security.approval_block_reason(user, run)
    if why:
        raise PermissionError(why)
    step = next((s for s in run["steps"] if s["agent_id"] == agent_id and s["status"] == "awaiting_approval"), None)
    if not step:
        raise ValueError("No pending approval for that agent in this run")
    T.audit(action="approval", run_id=run["id"], user=user["id"], user_name=user["name"], role=user["role"], agent_id=agent_id,
            agent_name=step["agent_name"], decision="approve" if approve else "reject", outcome="recorded", reason=comment or None)
    step["approval"] = {"by": user["name"], "role": user["role"], "approve": approve, "comment": comment or None, "ts": T.now()}
    run["status"] = "running"
    if approve:
        step["approved"], step["status"], step["note"] = True, "pending", None
    else:
        step["status"], step["note"] = "rejected", f"Rejected by {user['name']}" + (f": {comment}" if comment else "")
    owner = security.USERS[run["user"]]
    advance(run, owner)
    if run["user"] != user["id"]:
        T.notify([run["user"]], "decision", f"{step['agent_name']} {'approved' if approve else 'rejected'} by {user['name']}",
                 f"Run is now {run['status']}." + (f" Comment: {comment}" if comment else ""), "#runs")
    return run


def cancel(run, user, reason=""):
    """Feature 26: stop a run that is still waiting or running; remaining steps never execute."""
    if run["user"] != user["id"] and user["role"] != "Platform Admin":
        raise PermissionError("Only the requester or a Platform Admin can cancel this run")
    if run["status"] not in OPEN_STATES:
        raise ValueError(f"Run is already {run['status']}")
    for s in run["steps"]:
        if s["status"] in ("pending", "awaiting_approval"):
            s["status"], s["note"] = "cancelled", f"Cancelled by {user['name']}" + (f": {reason}" if reason else "")
    run["status"] = "cancelled"
    T.audit(action="cancel", run_id=run["id"], user=user["id"], user_name=user["name"], role=user["role"], decision="allow",
            outcome="cancelled", reason=reason or None)
    _finalize(run)
    return run


def rerun(run, user):
    """Feature 27: start a new run with the same intent, input and agents."""
    return create_run(user, run["intent"], run["input_text"], [s["agent_id"] for s in run["steps"]],
                      template_id=run.get("template_id"), rerun_of=run["id"])


def sweep_sla():
    """Feature 22: mark overdue approvals as escalated and notify Compliance Officers and Platform Admins once."""
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    escalated = []
    for run in list(T.RUNS.values()):
        if run["status"] != "awaiting_approval":
            continue
        for s in run["steps"]:
            if s["status"] == "awaiting_approval" and not s.get("escalated") and s.get("approval_due") and s["approval_due"] <= now:
                s["escalated"] = True
                T.audit(action="escalate", run_id=run["id"], user="system", user_name="SLA monitor", role="system",
                        agent_id=s["agent_id"], agent_name=s["agent_name"], decision="pending", outcome="escalated",
                        reason=f"Approval overdue since {s['approval_due']}")
                ids = [u["id"] for u in security.USERS.values() if u["role"] in security.APPROVER_ROLES]
                T.notify(ids, "escalation", f"Overdue approval escalated: {s['agent_name']}",
                         f"Requested by {run['user_name']}; due {s['approval_due']}", "#approvals")
                escalated.append({"run_id": run["id"], "agent_id": s["agent_id"]})
    return escalated


def _finalize(run):
    steps = run["steps"]
    done = [s for s in steps if s["status"] == "completed"]
    if run["status"] != "cancelled":
        run["status"] = ("completed" if len(done) == len(steps) else "partial" if done else "failed")
    verdicts = [s["output"].get("verdict", "") for s in done if s["output"]]
    if any(v == "Not ready" for v in verdicts): headline = "Not ready - significant gaps need to be resolved."
    elif any(v == "Needs refinement" for v in verdicts): headline = "Needs refinement before proceeding."
    elif done and any(v == "Ready" for v in verdicts):
        headline = "Ready for development" + (" - security controls must be applied." if any("High risk" in v for v in verdicts) else ".")
    elif done: headline = "Assessment completed successfully."
    else: headline = "No agent could be executed under your permissions."
    recs, seen = [], set()
    for s in done:
        for r in (s["output"].get("recommendations") or []):
            if r not in seen:
                seen.add(r); recs.append({"agent": s["agent_name"], "text": r})
    blocked = [{"agent": s["agent_name"], "status": s["status"], "reason": s["note"]} for s in steps if s["status"] in ("blocked", "rejected", "failed", "cancelled")]
    totals = {"agents_run": len(done), "cost_usd": round(sum(s["metrics"]["cost_usd"] for s in done), 4),
              "tokens": sum(s["metrics"]["tokens_in"] + s["metrics"]["tokens_out"] for s in done),
              "simulated_latency_sec": round(sum(s["metrics"]["simulated_latency_sec"] for s in done), 2)}
    run["result"] = {"headline": headline,
                     "sections": [{"agent": s["agent_name"], "provider": s["provider"], "verdict": s["output"].get("verdict"),
                                   "summary": s["output"].get("summary"), "findings": s["output"].get("findings", [])[:6],
                                   "data": s["output"].get("data", {})} for s in done],
                     "recommendations": recs[:10], "blocked": blocked, "totals": totals}


def pending_approvals(user):
    """Approval inbox: every step waiting for a human decision that this user may decide."""
    items = []
    for run in list(T.RUNS.values()):
        if run["status"] != "awaiting_approval" or not security.can_approve(user, run):
            continue
        for s in run["steps"]:
            if s["status"] == "awaiting_approval":
                a = registry.AGENTS[s["agent_id"]]
                items.append({"run_id": run["id"], "intent": run["intent"], "requested_by": run["user_name"],
                              "requester_role": run["role"], "created": run["created"], "agent_id": s["agent_id"],
                              "agent_name": s["agent_name"], "provider": s["provider"],
                              "data_classification": a["data_classification"], "cost_per_call": a["cost_per_call"],
                              "required_resources": a["required_resources"], "reason": s["note"],
                              "input_preview": (run["input_text"] or "")[:240], "due": s.get("approval_due"),
                              "overdue": bool(s.get("approval_due")) and s["approval_due"] <= T.now(), "escalated": s.get("escalated", False)})
    return sorted(items, key=lambda x: x["created"], reverse=True)
