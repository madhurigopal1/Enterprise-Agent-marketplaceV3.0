"""Input guardrails: PII redaction (feature 29) and prompt-injection detection (feature 30).

Pattern-based for the POC. Production: Azure AI Content Safety Prompt Shields + Microsoft Presidio / Purview.
"""
import re

PII_PATTERNS = [
    ("EMAIL", re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")),
    ("CARD", re.compile(r"\b(?:\d[ -]?){13,16}\b")),
    ("AADHAAR", re.compile(r"\b\d{4}\s?\d{4}\s?\d{4}\b")),
    ("PAN", re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b")),
    ("SSN", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    ("PHONE", re.compile(r"(?<!\w)\+?\d[\d\s().-]{8,}\d\b")),
    ("IBAN", re.compile(r"\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b")),
]

# Agents cleared for Confidential / Restricted data legitimately need the raw values (e.g. KYC).
REDACT_FOR = {"Public", "Internal"}


def redact(text: str):
    """Return (redacted_text, {TYPE: count})."""
    counts = {}
    out = text or ""
    for name, rx in PII_PATTERNS:
        out, n = rx.subn(f"[{name}]", out)
        if n:
            counts[name] = counts.get(name, 0) + n
    return out, counts


INJECTION_PATTERNS = [
    (re.compile(r"\bignore (all |any )?(the )?(previous|prior|above) (instructions|prompts?|rules)", re.I), "Instruction override"),
    (re.compile(r"\bdisregard (your|the|all) (rules|instructions|policy|policies)", re.I), "Instruction override"),
    (re.compile(r"\b(reveal|print|show|leak) (your |the )?(system prompt|hidden instructions|secrets?|api keys?)", re.I), "Secret / prompt exfiltration"),
    (re.compile(r"\byou are now (in )?(developer|dan|jailbreak|admin) mode", re.I), "Jailbreak persona"),
    (re.compile(r"\b(bypass|disable|turn off) (the )?(policy|guardrails?|approval|security|filters?)", re.I), "Control bypass"),
    (re.compile(r"\bact as (the )?(platform )?admin(istrator)?\b", re.I), "Privilege escalation"),
    (re.compile(r"<\s*/?\s*(system|assistant)\s*>", re.I), "Role tag injection"),
]


def detect_injection(*texts):
    hits = []
    for t in texts:
        for rx, label in INJECTION_PATTERNS:
            m = rx.search(t or "")
            if m:
                hits.append({"rule": label, "match": m.group(0)[:80]})
    return hits
