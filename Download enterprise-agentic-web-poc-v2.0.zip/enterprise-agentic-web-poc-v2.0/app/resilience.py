"""Agent resilience (feature 33): retries with backoff, circuit breaker per agent, admin fault injection."""
import random, time
from . import settings

BREAKERS = {}   # agent_id -> {"failures": int, "state": closed|open|half_open, "opened_at": float, "last_error": str}
FAULTS = {}     # agent_id -> failure probability 0..1 (fault injection for resilience testing)


class ProviderError(Exception):
    pass


def state(agent_id):
    b = BREAKERS.get(agent_id)
    if not b:
        return "closed"
    if b["state"] == "open" and time.time() - b["opened_at"] >= settings.SETTINGS["breaker_cooldown_sec"]:
        b["state"] = "half_open"
    return b["state"]


def is_open(agent_id):
    return state(agent_id) == "open"


def _fail(agent_id, err):
    b = BREAKERS.setdefault(agent_id, {"failures": 0, "state": "closed", "opened_at": 0.0, "last_error": None})
    b["failures"] += 1
    b["last_error"] = err
    if b["state"] == "half_open" or b["failures"] >= settings.SETTINGS["breaker_threshold"]:
        b["state"], b["opened_at"] = "open", time.time()


def _ok(agent_id):
    BREAKERS[agent_id] = {"failures": 0, "state": "closed", "opened_at": 0.0, "last_error": None}


def reset(agent_id):
    BREAKERS.pop(agent_id, None)


def call(agent, fn, sleep=time.sleep):
    """Run fn() with retries. Returns (result, attempts). Raises ProviderError when all attempts fail."""
    attempts, last = 0, None
    for i in range(settings.SETTINGS["max_retries"] + 1):
        attempts += 1
        try:
            rate = FAULTS.get(agent["id"], 0.0)
            if rate and random.random() < rate:
                raise ProviderError(f"Injected provider fault ({int(rate * 100)}% fault rate)")
            res = fn()
            _ok(agent["id"])
            return res, attempts
        except Exception as e:  # noqa: BLE001 - provider SDKs raise many types
            last = str(e)
            if i < settings.SETTINGS["max_retries"]:
                sleep(min(0.05 * (2 ** i), 0.4))   # exponential backoff (kept short for the demo)
    _fail(agent["id"], last)
    raise ProviderError(f"{last} after {attempts} attempt(s)")


def snapshot(agents):
    return [{"agent_id": aid, "agent": a["name"], "state": state(aid), "failures": BREAKERS.get(aid, {}).get("failures", 0),
             "last_error": BREAKERS.get(aid, {}).get("last_error"), "fault_rate": FAULTS.get(aid, 0.0)} for aid, a in agents.items()]
