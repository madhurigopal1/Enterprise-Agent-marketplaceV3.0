"""Feature 24: durable state. Snapshots all in-memory stores to a JSON file and restores them at start-up.

Enable with POC_PERSIST=true (file: POC_STATE_FILE, default ./data/state.json). Writes are atomic (temp file + rename).
Production: replace with PostgreSQL / Cosmos DB and an append-only audit store.
"""
import json, os, threading, time
from pathlib import Path
from . import registry, resilience, security, settings, telemetry as T, workflows

ENABLED = os.getenv("POC_PERSIST", "false").lower() == "true"
PATH = Path(os.getenv("POC_STATE_FILE", "data/state.json"))
_LOCK = threading.Lock()
STATUS = {"last_saved": None, "last_loaded": None, "error": None}


def dump():
    with T.LOCK:
        return {"version": 1, "saved_at": T.now(), "runs": T.RUNS, "audit": T.AUDIT, "feedback": T.FEEDBACK,
                "notifications": T.NOTIFICATIONS, "discovery_log": T.DISCOVERY_LOG, "spent": T.SPENT,
                "attempts": T.ATTEMPTS, "agents": registry.AGENTS, "templates": workflows.TEMPLATES,
                "budgets": {u: v["budget_usd"] for u, v in security.USERS.items()}, "settings": settings.SETTINGS,
                "faults": resilience.FAULTS}


def save(path: Path = None):
    path = Path(path or PATH)
    with _LOCK:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(dump(), default=str), encoding="utf-8")
        os.replace(tmp, path)
        STATUS["last_saved"] = T.now()
    return str(path)


def load(path: Path = None):
    path = Path(path or PATH)
    if not path.exists():
        return False
    d = json.loads(path.read_text(encoding="utf-8"))
    with T.LOCK:
        T.RUNS.clear(); T.RUNS.update(d["runs"])
        T.AUDIT[:] = d["audit"]; T.FEEDBACK[:] = d["feedback"]; T.NOTIFICATIONS[:] = d.get("notifications", [])
        T.DISCOVERY_LOG[:] = d["discovery_log"]; T.SPENT.clear(); T.SPENT.update(d["spent"]); T.ATTEMPTS.update(d["attempts"])
        registry.AGENTS.clear(); registry.AGENTS.update(d["agents"])
        workflows.TEMPLATES.clear(); workflows.TEMPLATES.update(d["templates"])
        for u, b in d.get("budgets", {}).items():
            if u in security.USERS:
                security.USERS[u]["budget_usd"] = b
        settings.SETTINGS.update(d.get("settings", {}))
        resilience.FAULTS.clear(); resilience.FAULTS.update(d.get("faults", {}))
    STATUS["last_loaded"] = T.now()
    return True


_last = [0.0]


def save_soon(min_interval=0.0):
    """Called after mutating requests; throttled so bursts write once."""
    if not ENABLED or time.time() - _last[0] < min_interval:
        return
    _last[0] = time.time()
    try:
        save()
        STATUS["error"] = None
    except Exception as e:  # noqa: BLE001
        STATUS["error"] = str(e)
