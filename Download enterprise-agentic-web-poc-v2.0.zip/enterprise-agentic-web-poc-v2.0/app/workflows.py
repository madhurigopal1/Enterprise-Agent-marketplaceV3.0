"""Reusable workflow templates (feature 28): a named intent + fixed agent list that anyone can run."""
from . import telemetry as T

TEMPLATES = {}


def _seed():
    for tid, name, desc, intent, agents in [
        ("tpl-readiness", "Requirement readiness check", "Six-agent review before a story enters a sprint",
         "Review this requirement and determine whether it is ready for development",
         ["req-quality", "testability", "architecture", "security", "estimation", "doc-gen"]),
        ("tpl-finance", "Month-end finance review", "Variance analysis with human approval", "Analyze budget variance and review financial exposure",
         ["fin-analysis", "doc-gen"]),
    ]:
        TEMPLATES[tid] = {"id": tid, "name": name, "description": desc, "intent": intent, "agent_ids": agents,
                          "owner": "sam", "owner_name": "Sam Carter", "shared": True, "created": T.now(), "uses": 0}


def visible(user):
    return [t for t in TEMPLATES.values() if t["shared"] or t["owner"] == user["id"]]


def create(user, d):
    tid = T.new_id("tpl")
    TEMPLATES[tid] = {"id": tid, "name": d["name"], "description": d.get("description", ""), "intent": d["intent"],
                      "agent_ids": d["agent_ids"], "owner": user["id"], "owner_name": user["name"],
                      "shared": bool(d.get("shared", False)), "created": T.now(), "uses": 0}
    return TEMPLATES[tid]


_seed()
