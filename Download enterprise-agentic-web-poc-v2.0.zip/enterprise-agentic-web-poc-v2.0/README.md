# Enterprise Agentic Web - Proof of Concept (v2.0.0)

See **docs/FEATURES.md** for all 40 features with user stories and acceptance criteria.

A runnable POC of a **governed, intent-driven marketplace for AI agents**: employees describe a business need, the platform discovers relevant agents, checks permissions, composes them, and returns one consolidated result with a full audit trail.

> **POC status:** Agents, providers (Neuro SAN, NANDA-inspired, Otari, AWS Bedrock, Enterprise API), SSO and data are **simulated**. The agent "skills" are deterministic rule-based analyses, not LLM calls. Latency, quality and success figures are seeded demo values. Replace `app/adapters.py::_call_provider` with real integrations.

## Quick start

**Windows (cmd / PowerShell)**
```
cd enterprise-agentic-web-poc-v1.0
run.bat
```
Or manually:
```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python run.py
```
**macOS / Linux:** `./run.sh`

Open **http://localhost:8000** (API docs at `/docs`). Requires Python 3.10+.

Run automated tests: `python -m pytest -q` (**51 tests**: 13 original + 9 approval/UI + 8 v1.1 + 21 v2.0 feature tests).

## What it demonstrates (MVP-1 to MVP-6)

| MVP capability | Where to see it |
|---|---|
| Agent registration | *Register Agent* tab / `POST /api/agents` |
| Intent-based discovery | *Marketplace* search and *Ask* preview / `POST /api/discover` |
| Unified consumption | Web UI, REST (`/docs`), manual "Try it" invocation |
| Multi-agent collaboration | *Ask* tab: Requirement -> Testability -> Architecture -> Security -> Estimation -> Documentation |
| Governance | Policy checks per step, scoped delegation, **Approvals** tab (human-in-the-loop inbox), lifecycle gates, audit trail |
| Observability | *Observability* tab: pilot KPIs vs targets, cost/tokens/latency per agent |

## Suggested test script (10 minutes)

1. **Intent composition.** As *Priya Nair (Business Analyst)* choose sample *Requirement readiness (vague spec)* -> **Compose & run**. Expect 6 agents, headline *Not ready*, findings on ambiguity, and a consolidated document. Re-run with *well-specified* sample -> headline *Ready for development*.
2. **Discovery by intent.** *Marketplace* -> search "check customer onboarding documents" -> KYC agent ranks first; Priya sees "No access" with the failing policy reason.
3. **RBAC/ABAC.** Priya -> *Governance* -> Policy simulator: Meera Collins -> Payment Analysis Agent -> denied on role **and** region.
4. **Human approval.** Switch to *Arjun Mehta (Finance Manager)* -> sample *Finance review* -> **Compose & run** -> step pauses at **Awaiting approval** and the red badge on the **Approvals** tab shows 1 -> open **Approvals** -> **Approve & continue** (or **Reject**) -> run resumes. Repeat as *Meera Collins* with *KYC onboarding check*.
5. **Scoped delegation.** Expand *Policy decision & delegation* on any step: scopes are limited to the agent's declared resources; no inheritance of user or upstream permissions.
6. **Lifecycle gate.** As *Kiran Rao (Agent Owner)* register a new agent -> try it (blocked: Registered). Switch to *Sam Carter (Platform Admin)* -> Marketplace -> agent -> promote Validated -> Certified -> Production. Kiran can now invoke it.
7. **Blocked agents.** Cloud Cost Optimizer (Validated) and Incident Triage (Experimental) are visible but cannot be invoked.
8. **Audit & KPIs.** *Governance* shows every allow/deny/approval; *Observability* shows KPI status against pilot targets.

## Demo identities (simulated SSO; sign in via the header dropdown)

| User | Role | Region | Clearance | Notable access |
|---|---|---|---|---|
| Priya Nair | Business Analyst | India | Internal | General agents only |
| Arjun Mehta | Finance Manager | India | Confidential | Finance + Payment agents |
| Meera Collins | Compliance Officer | UK | Confidential | KYC, Finance (UK allowed), full audit view |
| Kiran Rao | Agent Owner | India | Internal | Can register agents |
| Sam Carter | Platform Admin | US | Restricted | Lifecycle promotion, all data |

## Project layout

```
app/main.py          FastAPI routes + static UI hosting
app/registry.py      Catalog, lifecycle, TF-IDF semantic discovery (14 seeded agents)
app/orchestrator.py  Intent -> plan -> governed execution -> approvals -> consolidation
app/security.py      Signed-token SSO simulation, RBAC + ABAC zero-trust checks, scoped delegation
app/adapters.py      Agent Abstraction Layer (one adapter per provider, normalized contract)
app/skills.py        Deterministic demo agent logic
app/telemetry.py     Audit trail, discovery log, KPI computation
app/static/          UX: index.html, styles.css, app.js - six tabs incl. Approvals (no external dependencies)
tests/test_api.py    13 original API tests
tests/test_approvals_ui.py  9 approval / UI / cache regression tests
tests/test_features_v11.py  8 tests for the v1.1 features
tests/test_features_v20.py  21 tests for features 21-40
app/settings.py      runtime settings (Admin tab)
app/guardrails.py    PII redaction + prompt-injection guard
app/resilience.py    retries, circuit breaker, fault injection
app/workflows.py     workflow templates
app/persistence.py   JSON snapshot persistence
docs/FEATURES.md     Top 20 features with user stories and acceptance criteria
tests/e2e_browser.py optional Playwright click-through
scripts/check_ui.ps1 verifies the RUNNING server is this build
docs/                Architecture, UX deliverables, API reference
```

## Moving beyond the POC

- Replace `security.issue_token` with Entra ID / OIDC and map claims to role, region and clearance.
- Implement real calls in each adapter; keep the normalized response contract.
- Swap TF-IDF for embeddings + re-ranking; persist registry/audit in a database; add an asynchronous queue for long-running agents.
- Add real policy engine (OPA/Cedar), secrets management and per-agent workload identity.

## Human approval (where it happens)

| Where | What you see |
|---|---|
| **Ask** tab | The run pauses with `awaiting approval`; **Approve & continue** / **Reject** appear on the paused step |
| **Approvals** tab | Inbox of every paused step you may decide, with a red count badge on the tab |
| **Governance & Audit** | `approval_requested` -> `approval` (approve/reject) -> `invoke` rows |
| API | `GET /api/approvals`, `POST /api/runs/{run_id}/decision` `{"agent_id":"kyc","approve":true}` |

Who may decide: the requester, any **Compliance Officer**, or a **Platform Admin**. Others get HTTP 403.

## Troubleshooting: "I don't see the Approvals tab"

The header and footer show the build, e.g. **v1.0.0-approvals**. If you don't see that, an older copy is being served.

```powershell
# 1. Which build is running on port 8000?
Invoke-RestMethod http://127.0.0.1:8000/api/version
#    -> error/404 means an OLD build. Find and stop it:
Get-NetTCPConnection -LocalPort 8000 -State Listen | Select OwningProcess
Stop-Process -Id <OwningProcess> -Force

# 2. Start THIS folder
cd <path>\enterprise-agentic-web-poc-v1.0
.\run.bat

# 3. Verify (second window)
powershell -ExecutionPolicy Bypass -File .\scripts\check_ui.ps1

# 4. Browser: Ctrl+F5 (or an InPrivate window)
```

`run.py` now refuses to start if port 8000 is already taken, so two copies can no longer run at the same time. The UI is served with `Cache-Control: no-store` and versioned asset URLs, so the browser can't keep an old copy.

## New in v1.1 (try these)

| Feature | How to try |
|---|---|
| Rejection reasons and approval comments | Approve or Reject asks for a comment; it appears on the step, the report and the audit |
| Bulk approvals | As Arjun run *Finance review* twice → Approvals → Select all → Approve selected |
| My Runs | My Runs tab → Open any run |
| Ratings | On a completed step you own, click the stars |
| Kill switch | As Sam → Marketplace → Documentation Agent → Details → Kill switch: suspend → try it as Priya |
| Run report | Ask → Download report (.md) |
| Audit CSV | As Meera or Sam → Governance & Audit → Export CSV |

Optional: `POC_REQUIRE_REJECT_REASON=true` makes the rejection reason mandatory for API clients too.

## New in v2.0 (features 21-40)

| # | Feature | How to try |
|---|---|---|
| 21 | Segregation of duties | Sam → Admin → tick it → Arjun's own Finance run must be approved by Meera |
| 22 | Approval SLA + escalation | Admin → SLA 0 min → run Finance review → Meera sees "Overdue · escalated" and a notification |
| 23 | Notifications | Bell in the header |
| 24 | Persistence | `set POC_PERSIST=true` then `run.bat`; restart and your runs are still there |
| 25 | Dry run | Ask → Dry run (policy + cost) |
| 26/27 | Cancel / Re-run | Buttons on a run and in My Runs |
| 28 | Templates | Ask → "Start from a workflow template"; Save as template |
| 29 | PII redaction | Put an email or card number in Input; see "PII masked" on Documentation Agent |
| 30 | Prompt-injection guard | Type "ignore previous instructions" - warning, then 422 |
| 31 | Audit integrity | Governance → Verify integrity |
| 32 | Rate limit | Admin → runs per minute = 2, start 3 runs |
| 33 | Circuit breaker | Admin → Documentation Agent fault 100% → run it 3 times |
| 34 | Budgets | Admin → User budgets |
| 35 | Filters | Marketplace filter bar |
| 36 | Chargeback | Observability → Chargeback |
| 37/38 | Certification / edit | Marketplace → Details (sign in as Kiran or Sam to edit) |
| 39 | Prometheus | http://localhost:8000/metrics |
| 40 | Retention | Admin → Data retention → Preview / Purge |

Environment variables: `POC_PERSIST`, `POC_STATE_FILE`, `POC_SOD`, `POC_APPROVAL_SLA_MIN`, `POC_PII_REDACTION`, `POC_INJECTION_GUARD`, `POC_RUN_RATE_LIMIT`, plus the existing `POC_SECRET`, `POC_HOST`, `POC_PORT`.

Guardrails are pattern-based for the POC. For production use Azure AI Content Safety (Prompt Shields) and Microsoft Presidio / Purview.
